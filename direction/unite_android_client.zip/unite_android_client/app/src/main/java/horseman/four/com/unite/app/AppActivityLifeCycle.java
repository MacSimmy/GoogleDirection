package horseman.four.com.unite.app;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.util.Log;

/**
 * Created by Manu on 1/7/2017.
 */

class AppActivityLifeCycle implements Application.ActivityLifecycleCallbacks {
    private static final String TAG = "AppActivityLifeCycle";

    private static AppActivityLifeCycle instance;

    private AppActivityLifeCycle() {

    }

    static AppActivityLifeCycle getIns() {
        if (instance == null) {
            instance = new AppActivityLifeCycle();
        }
        return instance;
    }

    @Override
    public void onActivityCreated(Activity activity, Bundle bundle) {
        Log.d(TAG, activity.getLocalClassName() + " has created");
    }

    @Override
    public void onActivityStarted(Activity activity) {
        Log.d(TAG, activity.getLocalClassName() + " has started");
    }

    @Override
    public void onActivityResumed(Activity activity) {
        Log.d(TAG, activity.getLocalClassName() + " has resumed");
    }

    @Override
    public void onActivityPaused(Activity activity) {
        Log.d(TAG, activity.getLocalClassName() + " has paused");
    }

    @Override
    public void onActivityStopped(Activity activity) {
        Log.d(TAG, activity.getLocalClassName() + " has stopped");
    }

    @Override
    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
        Log.d(TAG, activity.getLocalClassName() + "'s onActivitySaveInstanceState has called");
    }

    @Override
    public void onActivityDestroyed(Activity activity) {
        Log.d(TAG, activity.getLocalClassName() + " has destroyed");
    }
}