package horseman.four.com.unite.screens.contacts;

import android.Manifest;
import android.annotation.TargetApi;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;

import horseman.four.com.unite.R;
import horseman.four.com.unite.screens.account.BaseActivity;

/**
 * Created by gurmeet.singh1 on 1/12/2017.
 */

public class ContactsActivity extends BaseActivity {
    private static final int PERMISSION_REQUEST_CONTACT = 101;

    private RecyclerView mRecycleView;
    private ContactAdapter mContactAdapter;
    private HashMap<String, String> mNumberNameMap;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initViews();
        askForContactPermission();
    }


    private void initViews() {
        setContentView(R.layout.activity_contact);
        mRecycleView = (RecyclerView) findViewById(R.id.recycler_view);


    }

    private void bindDataTOList() {
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        mRecycleView.setLayoutManager(mLayoutManager);
        mRecycleView.setItemAnimator(new DefaultItemAnimator());
        mRecycleView.addItemDecoration(new DividerItemDecoration(this));
        mContactAdapter = new ContactAdapter(this, startActionReadContacts());
        mRecycleView.setAdapter(mContactAdapter);
        mContactAdapter.notifyDataSetChanged();
    }


    /**
     * Start reading contacts and send them to parse.com
     */
    private ArrayList<ContactListData> startActionReadContacts() {
        boolean isFirstTime = true;
        ArrayList<ContactListData> contactListDatas = new ArrayList<>();
        ContactListData contactListData = null;
        int i = 0;
        if (isFirstTime) {
            mNumberNameMap = new HashMap<String, String>();
            ContentResolver cr = getContentResolver();
            Cursor cur = cr.query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);
            if (cur != null) {
                if (cur.getCount() > 0) {
                    while (cur.moveToNext()) {
                        String id = cur.getString(cur.getColumnIndex(ContactsContract.Contacts._ID));
                        String name = cur.getString(cur.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                        String image_uri = cur
                                .getString(cur
                                        .getColumnIndex(ContactsContract.CommonDataKinds.Phone.PHOTO_URI));
                        if (Integer.parseInt(cur.getString(cur.getColumnIndex(ContactsContract.Contacts
                                .HAS_PHONE_NUMBER))) > 0) {
                            Log.e("MyContacts", "name : " + name + ", ID : " + id);
                            Cursor pCur = cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,
                                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?", new String[]{id}, null);
                            if (pCur != null) {
                                while (pCur.moveToNext()) {
                                    i++;

                                    String phone = pCur.getString(pCur.getColumnIndex(ContactsContract
                                            .CommonDataKinds.Phone.NUMBER));
                                    phone = reformatPhoneNumber(phone);
                                    if (phone != null) {
                                        Log.e("MyContacts", "phone" + phone);
                                        String trimmedName = name.trim();
                                        mNumberNameMap.put(phone, trimmedName);
                                        contactListDatas.add(new ContactListData(phone, trimmedName, "c " + i, image_uri));

                                    }
                                }
                                pCur.close();
                            }
                        }
                    }
                }
                cur.close();
            }
        }
        return contactListDatas;
    }

    private String reformatPhoneNumber(String phone) {
        phone = phone.replaceAll("[^0-9]", "");
        int length = phone.length();
        if (length < 10) {
            //We do not want this number.
            return null;
        } else if (length > 10) {
            //we have to remove extra numbers from starts
            phone = phone.substring(length - 10, length);
            return phone;
        } else {
            //phone number is valid.
            return phone;
        }
    }

    public void askForContactPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {

                // Should we show an explanation?
                if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                        Manifest.permission.READ_CONTACTS)) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("Contacts access needed");
                    builder.setPositiveButton(android.R.string.ok, null);
                    builder.setMessage("please confirm Contacts access");//TODO put real question
                    builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @TargetApi(Build.VERSION_CODES.M)
                        @Override
                        public void onDismiss(DialogInterface dialog) {
                            requestPermissions(
                                    new String[]
                                            {Manifest.permission.READ_CONTACTS}
                                    , PERMISSION_REQUEST_CONTACT);
                        }
                    });
                    builder.show();
                    // Show an expanation to the user *asynchronously* -- don't block
                    // this thread waiting for the user's response! After the user
                    // sees the explanation, try again to request the permission.

                } else {

                    // No explanation needed, we can request the permission.

                    ActivityCompat.requestPermissions(this,
                            new String[]{Manifest.permission.READ_CONTACTS},
                            PERMISSION_REQUEST_CONTACT);

                    // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                    // app-defined int constant. The callback method gets the
                    // result of the request.
                }
            } else {
                bindDataTOList();
            }
        } else {
            bindDataTOList();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_CONTACT: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    startActionReadContacts();
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.

                } else {
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }
}
