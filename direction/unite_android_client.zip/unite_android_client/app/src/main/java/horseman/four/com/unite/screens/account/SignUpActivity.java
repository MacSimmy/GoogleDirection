package horseman.four.com.unite.screens.account;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import horseman.four.com.unite.R;
import horseman.four.com.unite.app.UniteApp;
import horseman.four.com.unite.listener.IPrefrenceHelperKeys;
import horseman.four.com.unite.pojo.VO.LoginVO;
import horseman.four.com.unite.preference.PreferenceHelper;
import horseman.four.com.unite.utils.AppScreens;

/**
 * Created by naresh.kaushik on 12/23/2016.
 */

public class SignUpActivity extends BaseActivity implements SignUpView, View.OnClickListener {

    private ProgressBar mProgressBar;
    private EditText nameEditText, passwordEditText;
    private EditText mPhoneEditText;
    private Button signUp, signIn;
    private SignUpPresenterImpl signUpPresenter;
    private PreferenceHelper mPreferenceHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initlizeView();
       // initPresenter();
    }

    private void initlizeView() {
        setContentView(R.layout.activity_signup);
        mProgressBar = (ProgressBar) findViewById(R.id.progress);
        signUp = (Button) findViewById(R.id.signUpButton);
        signIn = (Button) findViewById(R.id.signInButton);
        nameEditText = (EditText) findViewById(R.id.nameEditText);
        passwordEditText = (EditText) findViewById(R.id.passwordEditText);
        mPhoneEditText = (EditText) findViewById(R.id.phone_edittext);

        signUp.setOnClickListener(this);
        signIn.setOnClickListener(this);

        mPreferenceHelper = PreferenceHelper.getAppPrefs(this);
    }

    private void initPresenter() {
        signUpPresenter = new SignUpPresenterImpl(this);
    }

    @Override
    public void showProgress() {
        mProgressBar.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideProgress() {
        mProgressBar.setVisibility(View.GONE);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.signUpButton:

                break;
            case R.id.signInButton:
                moveToNextScreen(AppScreens.SIGNIN);
                break;
        }
    }

    @Override
    public boolean isValidInput() {

        return false;
    }

    @Override
    public void moveToNextScreen(AppScreens screen) {
       // mPreferenceHelper.saveIntValue(IPrefrenceHelperKeys.IS_OTP_COMMING_STATUS, AppScreens.SIGNUP.getValue());
        if (screen == AppScreens.SIGNIN) {
            UniteApp.getInstance().startActivity(AppScreens.SIGNIN, true);
        }
    }

    @Override
    public void onRegistrationFailed(Object object) {
        if (object instanceof LoginVO)
            Toast.makeText(this, ((LoginVO) object).getErrors(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onWebServiceFailed(Object object) {
        if (object instanceof LoginVO)
            Toast.makeText(this, ((LoginVO) object).getErrors(), Toast.LENGTH_SHORT).show();
    }
}
