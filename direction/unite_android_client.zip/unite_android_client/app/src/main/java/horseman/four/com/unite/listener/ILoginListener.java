package horseman.four.com.unite.listener;

/**
 * Created by bhavesh.kumar on 12/18/2016.
 */

public interface ILoginListener extends IViewControllerListener {


}
