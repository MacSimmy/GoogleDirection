package horseman.four.com.unite.utils;

/**
 * Created by Bharat Bhushan on 14-01-2017.
 */

public enum AppScreens {
    SIGNUP(1),
    SIGNIN(2),
    DASHBOARD(3),
    FORGOT_PASSWORD(6),
    OTP_VERFICATION(7),
    CONTACTS(8);
    int value;

    AppScreens(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
