package horseman.four.com.unite.screens.account;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.List;
import horseman.four.com.unite.R;
import horseman.four.com.unite.app.UniteApp;
import horseman.four.com.unite.listener.IPrefrenceHelperKeys;
import horseman.four.com.unite.network.RestApiBuilder;
import horseman.four.com.unite.network.RestApiServices;
import horseman.four.com.unite.pojo.VO.LoginVO;
import horseman.four.com.unite.preference.LocalStorage;
import horseman.four.com.unite.preference.PreferenceHelper;
import horseman.four.com.unite.utils.AppScreens;
import horseman.four.com.unite.utils.ConstantValues;


/**
 * Created by Gurmeet Singh on 14-01-2017.
 */

public class LoginActivity extends BaseActivity implements LoginView, View.OnClickListener {

    private ProgressBar mProgressBar;
    private EditText passwordEditText;
    private EditText mPhoneEditText;
    private Button signUp, signIn;

    private LoginPresenterImpl mLoginPresenter;
   // private ProfileTracker mProfileTracker;
    private String TAG = "TAG";
    private Dialog validationDialog;
    private TextView mForgotTv, mContacts;
    private PreferenceHelper mPreferenceHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initlizeView();
       // initPresenter();
    }

    private void initlizeView() {
        setContentView(R.layout.activity_login);
        mProgressBar = (ProgressBar) findViewById(R.id.progress);
        signUp = (Button) findViewById(R.id.signUpButton);
        signIn = (Button) findViewById(R.id.signInButton);
        passwordEditText = (EditText) findViewById(R.id.passwordEditText);
        mPhoneEditText = (EditText) findViewById(R.id.phone_edittext);
        mForgotTv = (TextView) findViewById(R.id.forgot_tv);
        mContacts = (TextView) findViewById(R.id.contact_tv);

        mForgotTv.setOnClickListener(this);
        signUp.setOnClickListener(this);
        signIn.setOnClickListener(this);
        mContacts.setOnClickListener(this);

        mPreferenceHelper = PreferenceHelper.getAppPrefs(this);
        LocalStorage.getInstance().saveStatus(false);

    }

    private void initPresenter() {

        RestApiServices mrestApiServices;
        mrestApiServices = RestApiBuilder.providesService();
        mLoginPresenter = new LoginPresenterImpl(mrestApiServices, this);

    }


    @Override
    public void onDestroy() {
        super.onDestroy();
    }


    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    public void showProgress() {
        mProgressBar.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideProgress() {
        mProgressBar.setVisibility(View.GONE);
    }

    @Override
    public void onPause() {
        super.onPause();

    }

    @Override
    public void moveToNextScreen(AppScreens screen, Object object) {
        if (screen == AppScreens.SIGNIN) {
            UniteApp.getInstance().startActivity(AppScreens.SIGNUP);
        }
    }

    @Override
    public void setEmailError(String error) {

    }

    @Override
    public void setPhoneError(String error) {

    }


    @Override
    public void setPasswordError(String error) {
        passwordEditText.requestFocus();
        passwordEditText.setError(error);
    }

    @Override
    public void showToastError(String error) {
        Toast.makeText(this, error, Toast.LENGTH_SHORT).show();
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.signUpButton:
                UniteApp.getInstance().startActivity(AppScreens.SIGNUP);
              /*  moveToNextScreen(AppScreens.SIGNUP, null);*/
                break;
            case R.id.forgot_tv:
              //  UniteApp.getInstance().startActivity(AppScreens.FORGOT_PASSWORD);
                break;
            case R.id.contact_tv:
                UniteApp.getInstance().startActivity(AppScreens.CONTACTS);
                break;
        }
    }

}
