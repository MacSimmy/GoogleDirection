package horseman.four.com.unite.screens.map;

import android.Manifest;
import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;

import com.aurelhubert.ahbottomnavigation.AHBottomNavigation;
import com.aurelhubert.ahbottomnavigation.AHBottomNavigationItem;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import horseman.four.com.unite.R;
import horseman.four.com.unite.data.rest.models.Message;
import horseman.four.com.unite.screens.map.direction.DirectionCallback;
import horseman.four.com.unite.screens.map.direction.GoogleDirection;
import horseman.four.com.unite.screens.map.direction.constant.TransportMode;
import horseman.four.com.unite.screens.map.direction.model.Direction;
import horseman.four.com.unite.screens.map.direction.util.DirectionConverter;
import horseman.four.com.unite.screens.map.model.ChatMessage;
import horseman.four.com.unite.screens.map.mqtt.MessageListener;
import horseman.four.com.unite.screens.map.mqtt.MqttManager;
import horseman.four.com.unite.screens.map.mqtt.MqttService;

public class UniteDualMapActivity extends FragmentActivity implements OnMapReadyCallback, GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener, DirectionCallback,
        LocationListener, MessageListener, ChatManager.ChatCallbacks, GoogleMap.OnMapClickListener, GoogleMap.OnMarkerClickListener, GoogleMap.OnMapLongClickListener {

    public static final String TAG = "UniteDualMapActivity";
    public static final String mMapServerKey = "AIzaSyAF7ITgi6s_1vtghsYWikIR0MRalr-JDjk";

    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 101;
    private static final long ANIMATION_DURATION = 300;

    private GoogleMap mMap;
    private GoogleApiClient mGoogleApiClient;
    private LocationRequest mLocationRequest;

    private AHBottomNavigation mBottomNavigation;
    private LatLngBounds mCurrentCameraBound = null;

    private List<Polyline> mPolyLines = new ArrayList<Polyline>();

    private Location mCityCenter = new Location("jkbhck");


    private View mChatFrame;
    private MqttManager mMqttManager;
    private ChatManager mChatManager;
    private Location mCurrentLocation;
    private Location mPreviousLocation;
    private boolean mIsInitialMapSet = false;

    private int mChatMessageCount = 0;
    private HashMap<String, Marker> mUserMarkers = null;
    private Marker mUserMarker;

    private boolean mIsChatWindowVisible = false;

    private boolean isWalkingNavActive = true;
    private boolean isPolylineDrawn = false;
    private MQTTMessageReceiver messageIntentReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unite_dual_map);
        mUserMarkers = new HashMap<>();
        initializeAllViews();
        initializeMap();
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkLocationPermission()) {
                buildGoogleApiClient();
            }
        } else {
            buildGoogleApiClient();
        }
        mMqttManager = MqttManager.getINST();
        mChatManager = new ChatManager(this, mChatFrame, mMqttManager, this);
        mChatManager.initChatFramework();
        mMqttManager.setChatManager(mChatManager);
        mCityCenter.setLatitude(28.5747);
        mCityCenter.setLongitude(77.356);
       /* Intent svc = new Intent(this, MqttService.class);
        startService(svc);

        messageIntentReceiver = new MQTTMessageReceiver();
        IntentFilter intentCFilter = new IntentFilter(MqttService.MQTT_MSG_RECEIVED_INTENT);
        registerReceiver(messageIntentReceiver, intentCFilter);*/
    }

    private void initializeMap() {
        GoogleApiAvailability apiAvailability = GoogleApiAvailability.getInstance();
        int resultCode = apiAvailability.isGooglePlayServicesAvailable(this);
        if (resultCode == ConnectionResult.SUCCESS) {
            // Obtain the SupportMapFragment and get notified when the map is ready to be used.
            SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                    .findFragmentById(R.id.map);
            mapFragment.getMapAsync(this);
        } else {
            // Show a custom error message
            apiAvailability.getErrorDialog(this, resultCode, PLAY_SERVICES_RESOLUTION_REQUEST).show();
        }
    }


    @Override
    public void onResume(){
        super.onResume();
        if(mMqttManager == null){
            mMqttManager = MqttManager.getINST();
        }
        mMqttManager.initConnection("example_topic");
        mMqttManager.setChatManager(mChatManager);
    }
    private void initializeAllViews() {
        mChatFrame = findViewById(R.id.frame_chat);
        mBottomNavigation = (AHBottomNavigation) findViewById(R.id.bottom_navigation);
        setBottomNavigation();
    }


    private void setBottomNavigation() {
        AHBottomNavigationItem tabTransit = new AHBottomNavigationItem(getString(R.string.transit),
                ContextCompat.getDrawable(this, R.drawable.ic_directions_car_black_24dp));
        AHBottomNavigationItem tabChat = new AHBottomNavigationItem(getString(R.string.chat),
                ContextCompat.getDrawable(this, R.drawable.ic_chat_black_24dp));
        AHBottomNavigationItem tabWalking = new AHBottomNavigationItem(getString(R.string
                .walking), ContextCompat.getDrawable(this, R.drawable.ic_directions_walk_black_24dp));

        AHBottomNavigationItem tabReCenter = new AHBottomNavigationItem(getString(R.string
                .recenter), ContextCompat.getDrawable(this, R.drawable
                .ic_center_focus_strong_black_24dp));
        mBottomNavigation.addItem(tabWalking);
        mBottomNavigation.addItem(tabTransit);
        mBottomNavigation.addItem(tabChat);
        mBottomNavigation.addItem(tabReCenter);
        mBottomNavigation.setNotificationBackgroundColor(Color.parseColor("#F63D2B"));
        /*set the coloring effects*/
        mBottomNavigation.setDefaultBackgroundColor(ContextCompat.getColor(this, R.color
                .bottom_navigation_background));
        mBottomNavigation.setTitleState(AHBottomNavigation.TitleState.SHOW_WHEN_ACTIVE);
        mBottomNavigation.setTitleTextSize(getResources().getDimension(R.dimen
                .bottom_active_text_size), getResources().getDimension(R.dimen
                .bottom_inactive_text_size));
        mBottomNavigation.setBehaviorTranslationEnabled(false);
        mBottomNavigation.setAccentColor(ContextCompat.getColor(this, R.color
                .bottom_navigation_accent));
        mBottomNavigation.setInactiveColor(ContextCompat.getColor(this, R.color
                .bottom_navigation_inactive));
        mBottomNavigation.setForceTint(true);
        mBottomNavigation.setColored(false);
        mBottomNavigation.setCurrentItem(isWalkingNavActive ? 0 : 1);
        mBottomNavigation.setUseElevation(true, 2);
        mBottomNavigation.setOnTabSelectedListener(new AHBottomNavigation.OnTabSelectedListener() {
            @Override
            public boolean onTabSelected(int position, boolean wasSelected) {
                switch (position) {
                    case 0:
                        isWalkingNavActive = true;
                        getDirectionWalking();
                        return true;
                    case 1:
                        isWalkingNavActive = false;
                        getDirectionDriving();
                        return true;
                    case 2:
                        showChatWindow();
                        return true;
                    case 3:
                        recenterTheMapCamera();
                        mBottomNavigation.setCurrentItem(isWalkingNavActive ? 0 : 1);
                        return true;
                    default:
                        return true;
                }
            }
        });
    }


    private void recenterTheMapCamera() {
        //update camera position
        if (mMap != null) {
            LatLng currentLatLng = new LatLng(mCurrentLocation.getLatitude(), mCurrentLocation
                    .getLongitude());
            mCurrentCameraBound = LatLngBounds.builder().include(currentLatLng).build();
           /* mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(mCurrentCameraBound
                    .getCenter(), 17));*/
            mMap.animateCamera(CameraUpdateFactory.newLatLngBounds(mCurrentCameraBound, 40), 2000, null);
        }
        mBottomNavigation.setCurrentItem(isWalkingNavActive ? 0 : 1);


    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        MapStyleOptions styleOptions = MapStyleOptions.loadRawResourceStyle(this, R.raw.map_style);
        mMap.setMapStyle(styleOptions);
        mMap.setOnMapClickListener(this);
        mMap.setOnMarkerClickListener(this);
        mMap.setOnMapLongClickListener(this);
    }

    private boolean checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);


            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);
            }
            return false;
        } else {
            return true;
        }
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {

        // request f or location updates
        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(5000);
        mLocationRequest.setFastestInterval(100);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);
        } else {
            checkLocationPermission();
        }
    }

    @Override
    public void onConnectionSuspended(int i) {
        Log.e(TAG, "onConnectionSuspended called with reason " + i);

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        Log.e(TAG, "onConnectionFailed called with reason " + connectionResult.getErrorMessage());
    }

    @Override
    public void onLocationChanged(Location location) {
        Log.d(TAG, "location updated " + location.toString());
        mCurrentLocation = location;
        if (!mIsInitialMapSet) {
            mCurrentLocation = location;
            setInitialMap();
            mIsInitialMapSet = true;
        } else {
            updateCurrentMarker();
        }
        mPreviousLocation = mCurrentLocation;
    }

    private void updateCurrentMarker() {
        try {
            if (mCurrentLocation != null) {
                LatLng currentLatLng = new LatLng(mCurrentLocation.getLatitude(), mCurrentLocation
                        .getLongitude());
                if (mUserMarker == null && mMap != null) {
                    mUserMarker = mMap.addMarker(new MarkerOptions()
                            .position(currentLatLng)
                            .title("You"));
                }
                if (mUserMarker != null) {
                    mUserMarker.setPosition(currentLatLng);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setInitialMap() {
        if (mCurrentLocation != null) {
            recenterTheMapCamera();
        }
    }

    private void buildGoogleApiClient() {
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();
        mGoogleApiClient.connect();
        Log.d(TAG, "connecting google Api client");
    }


    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    if (ContextCompat.checkSelfPermission(this,
                            Manifest.permission.ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED) {

                        if (mGoogleApiClient == null) {
                            buildGoogleApiClient();
                        }
                    }

                } else {
                    Log.e(TAG, "User does not provide permission to update location.");
                    Snackbar.make(findViewById(R.id.activity_unite_group_map),
                            "You have to grant permission to update get location updates from device",
                            Snackbar.LENGTH_INDEFINITE).setAction("Update Location", new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            if (checkLocationPermission()) {
                                buildGoogleApiClient();
                            }
                        }
                    });
                }
            }
        }
    }

    @Override
    public void chatMessageArrived(ChatMessage message) {
        Log.d(TAG, "Message Arrived: " + message.getMessage());
    }

    @Override
    public void showChatWindow() {
        if (!mIsChatWindowVisible) {
            mIsChatWindowVisible = true;
            ViewGroup parent = (ViewGroup) mChatFrame.getParent();
            int distance = parent.getHeight() - mChatFrame.getTop();
            AnimatorSet animatorSet = new AnimatorSet();
            animatorSet.setDuration(ANIMATION_DURATION);
            animatorSet.setInterpolator(new DecelerateInterpolator(1));
            mChatFrame.setVisibility(View.VISIBLE);
            animatorSet.playTogether(
                    // ObjectAnimator.ofFloat(mBannerInfoFrame, "alpha", 0, 1),
                    ObjectAnimator.ofFloat(mChatFrame, "translationY", distance, 0));
            animatorSet.start();

            //reset chat message count.
            mChatMessageCount = 0;
            mBottomNavigation.refresh();
            mBottomNavigation.removeAllItems();
            setBottomNavigation();
        }
    }

    @Override
    public void hideChatWindow() {
        if (mIsChatWindowVisible) {
            mIsChatWindowVisible = false;
            ViewGroup parent = (ViewGroup) mChatFrame.getParent();
            int distance = parent.getHeight() - mChatFrame.getTop();
            AnimatorSet animatorSet = new AnimatorSet();
            animatorSet.setDuration(ANIMATION_DURATION);
            animatorSet.setInterpolator(new AccelerateInterpolator(1));
            animatorSet.addListener(new Animator.AnimatorListener() {
                @Override
                public void onAnimationStart(Animator animation) {

                }

                @Override
                public void onAnimationEnd(Animator animation) {
                    mChatFrame.setVisibility(View.GONE);
                    if (isWalkingNavActive) {
                        mBottomNavigation.setCurrentItem(0);
                    } else {
                        mBottomNavigation.setCurrentItem(1);
                    }
                }

                @Override
                public void onAnimationCancel(Animator animation) {

                }

                @Override
                public void onAnimationRepeat(Animator animation) {

                }
            });
            animatorSet.playTogether(
                    //ObjectAnimator.ofFloat(mBannerInfoFrame, "alpha", 1, 0),
                    ObjectAnimator.ofFloat(mChatFrame, "translationY", 0, distance));
            animatorSet.start();
        }
    }

    @Override
    public void updateNewChatNotification() {
        if (!mIsChatWindowVisible) {
            mChatMessageCount++;
            mBottomNavigation.setNotification(String.valueOf(mChatMessageCount), 2);
        } else {
            mChatMessageCount = 0;
        }
    }

    @Override
    public void onMapClick(LatLng latLng) {

    }

    @Override
    public boolean onMarkerClick(Marker marker) {
        return false;
    }

    @Override
    public void onMapLongClick(LatLng latLng) {

    }


    private void getDirectionWalking() {
        if (!isPolylineDrawn && mCurrentLocation != null) {
            GoogleDirection.withServerKey(mMapServerKey)
                    .from(new LatLng(mCurrentLocation.getLatitude(), mCurrentLocation.getLongitude()))
                    .to(new LatLng(mCityCenter.getLatitude(), mCityCenter.getLongitude()))
                    .transportMode(TransportMode.WALKING)
                    .execute(this);
        }
    }

    private void getDirectionDriving() {
        if (isPolylineDrawn && mCurrentLocation != null) {
            GoogleDirection.withServerKey(mMapServerKey)
                    .from(new LatLng(mCurrentLocation.getLatitude(), mCurrentLocation.getLongitude()))
                    .to(new LatLng(mCityCenter.getLatitude(), mCityCenter.getLongitude()))
                    .transportMode(TransportMode.DRIVING)
                    .execute(this);
        }
    }

    @Override
    public void onDirectionSuccess(Direction direction, String rawBody) {
        if (direction.isOK()) {
            mMap.addMarker(new MarkerOptions().position(new LatLng(mCityCenter.getLatitude(),
                    mCityCenter.getLongitude())));

            ArrayList<LatLng> directionPositionList = direction.getRouteList().get(0).getLegList().get(0).getDirectionPoint();

            for (Polyline polyline : mPolyLines) {
                polyline.remove();
            }
            mPolyLines.clear();
            Polyline polyline = mMap.addPolyline(DirectionConverter.createPolyline(this,
                    directionPositionList, 10,
                    ContextCompat.getColor(this, R.color.color_walking_path)));
            mPolyLines.add(polyline);
            isPolylineDrawn = !isPolylineDrawn;
        }

    }

    @Override
    public void onDirectionFailure(Throwable t) {
        Snackbar.make(mBottomNavigation, t.getMessage(), Snackbar.LENGTH_SHORT).show();
    }


    public class MQTTMessageReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle notificationData = intent.getExtras();
            ChatMessage chatMessage = notificationData.getParcelable(MqttService.MQTT_MSG_RECEIVED_MSG);
            mChatManager.chatMessageArrived(chatMessage);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
      /*  Intent svc = new Intent(this, MqttService.class);
        stopService(svc);
        unregisterReceiver(messageIntentReceiver);*/
    }
}
