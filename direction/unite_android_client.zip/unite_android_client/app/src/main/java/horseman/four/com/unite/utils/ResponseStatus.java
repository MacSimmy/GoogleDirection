package horseman.four.com.unite.utils;

/**
 * Created by naresh.kaushik on 12/26/2016.
 */

public enum ResponseStatus {
    SUCCESS(1),
    FAIL(0);
    int value;

    ResponseStatus(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
