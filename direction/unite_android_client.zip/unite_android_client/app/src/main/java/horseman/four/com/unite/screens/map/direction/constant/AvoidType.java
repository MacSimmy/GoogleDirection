package horseman.four.com.unite.screens.map.direction.constant;

/**
 * Created by global on 17/1/17.
 */

public class AvoidType {
    public static final String TOLLS = "tolls";
    public static final String HIGHWAYS = "highways";
    public static final String FERRIES = "ferries";
    public static final String INDOOR = "indoor";
}
