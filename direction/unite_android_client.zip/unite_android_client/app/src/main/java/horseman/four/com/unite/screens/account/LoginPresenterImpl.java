package horseman.four.com.unite.screens.account;


import android.text.TextUtils;


import horseman.four.com.unite.app.UniteApp;
import horseman.four.com.unite.listener.ILoginListener;
import horseman.four.com.unite.listener.IPrefrenceHelperKeys;
import horseman.four.com.unite.mvp.BasePresenter;
import horseman.four.com.unite.network.RestApiServices;
import horseman.four.com.unite.pojo.PO.LoginPO;
import horseman.four.com.unite.pojo.VO.LoginVO;
import horseman.four.com.unite.utils.AppScreens;
import horseman.four.com.unite.utils.ResponseStatus;
import rx.Subscription;
import rx.subscriptions.CompositeSubscription;

/**
 * Created by bhavesh.kumar on 12/19/2016.
 */

public class LoginPresenterImpl implements LoginPresenter, ILoginListener {
    private final RestApiServices service;
    private final LoginView view;
    private CompositeSubscription subscriptions;

    public LoginPresenterImpl(RestApiServices service, LoginView view) {
        this.service = service;
        this.view = view;
        this.subscriptions = new CompositeSubscription();
    }

    @Override
    public void doLogin(LoginPO loginPO) {
        if (isValidInput(loginPO)) {

            view.showProgress();
            UniteApp.getInstance().getSagoonPref().saveUserInfo(loginPO);
            Subscription subscription = service.getLoginInfo(this, loginPO);
            subscriptions.add(subscription);
        }
    }


    @Override
    public void resume() {

    }

    @Override
    public void pause() {

    }

    @Override
    public void stop() {
        subscriptions.unsubscribe();
    }

    @Override
    public void destroy() {

    }

    @Override

    public boolean isValidInput(LoginPO loginPO) {
        boolean isEmailOrPhoneValid = false;
        if (loginPO.getLoginType() == null && TextUtils.isEmpty(loginPO.getUsername()))
            view.showToastError("Either enter email or phone.");
        else if (loginPO.getLoginType().equals("email")) {
            if (TextUtils.isEmpty(loginPO.getUsername()))
                view.setEmailError("Please enter Email id.");

        } else if (loginPO.getLoginType().equals("phone")) {
            if (TextUtils.isEmpty(loginPO.getUsername()))
                view.setPhoneError("Please enter Phone Number.");
            else if (TextUtils.isEmpty(loginPO.getUsername()) || loginPO.getUsername().length() < 10)
                view.setPhoneError("Invalid Phone Number.");
            else
                isEmailOrPhoneValid = true;
        }

        if (isEmailOrPhoneValid && TextUtils.isEmpty(loginPO.getPassword())) {
            view.setPasswordError("Please enter Password.");
        } else if (isEmailOrPhoneValid)
            return true;
        return false;
    }

    @Override
    public void onLoginFailed(Object object) {
        if (object instanceof LoginVO)
            view.showToastError(((LoginVO) object).getErrors());
    }

    @Override
    public void onWebServiceFailed(Object object) {
        if (object instanceof LoginVO)
            view.showToastError(((LoginVO) object).getErrors());
    }

    @Override
    public void notifyViewOnSuccess(Object object) {
        view.hideProgress();
        if (object instanceof LoginVO) {

            LoginVO loginVO = (LoginVO) object;
            if (loginVO.getStatus() == ResponseStatus.SUCCESS.getValue()) {
                UniteApp.getInstance().getSagoonPref().saveStringValue(IPrefrenceHelperKeys.TOKEN, loginVO.getToken());
                    UniteApp.getInstance().startActivity(AppScreens.DASHBOARD);
                }
            } else {
                onLoginFailed(object);
            }
        }

    @Override
    public void notifyViewOnFailure(Object object) {
        view.hideProgress();
        onWebServiceFailed(object);
    }


}
