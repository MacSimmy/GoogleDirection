package horseman.four.com.unite.data.rest.models;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Manu on 1/8/2017.
 */

public class Message {

    @SerializedName("id")
    private String id;

    @SerializedName("message")
    private String message;

    @SerializedName("groupId")
    private String groupId;

    @SerializedName("sender")
    private String sender;


    @SerializedName("timestamp")
    private long timestamp;

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
