package horseman.four.com.unite.app;

/**
 * Created by Manu on 1/8/2017.
 */

public class AppConfig {

    public static final String SERVICE_BASE_URL = "base url point here";
}
