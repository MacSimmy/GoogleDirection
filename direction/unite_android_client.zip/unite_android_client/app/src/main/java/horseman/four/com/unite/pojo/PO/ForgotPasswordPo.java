package horseman.four.com.unite.pojo.PO;

/**
 * Created by gurmeet.singh1 on 12/27/2016.
 */

public class ForgotPasswordPo {
    private String reset_by;
    private String phone;
    private String email;
    private String country_code;
    private String token;
    private String country_id;

    public ForgotPasswordPo() {
    }

    public String getCountry_id() {
        return country_id;
    }

    public void setCountry_id(String country_id) {
        this.country_id = country_id;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getReset_by() {
        return reset_by;
    }

    public void setReset_by(String reset_by) {
        this.reset_by = reset_by;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCountry_code() {
        return country_code;
    }

    public void setCountry_code(String country_code) {
        this.country_code = country_code;
    }
}
