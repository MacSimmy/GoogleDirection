package horseman.four.com.unite.data.rest.models;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Manu on 1/7/2017.
 */

public class User {

    @SerializedName("id")
    private String id;


    @SerializedName("name")
    private String name;

    @SerializedName("username")
    private String username;

    @SerializedName("deviceId")
    private String deviceId;

    @SerializedName("password")
    private String password;

    @SerializedName("mobileNo")
    private String mobileNo;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

}
