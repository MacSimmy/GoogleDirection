package horseman.four.com.unite.data.rest.models;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by Manu on 1/7/2017.
 */

public class Group {

    @SerializedName("id")
    private String id;

    @SerializedName("groupName")
    private String groupName;

    @SerializedName("users")
    private List<String> users;

    @SerializedName("status")
    private boolean status;

    @SerializedName("timestamp")
    private long timestamp;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public List<String> getUsers() {
        return users;
    }

    public void setUsers(List<String> users) {
        this.users = users;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }


}
