package horseman.four.com.unite.data.local;

import android.support.annotation.NonNull;

import java.util.List;

import horseman.four.com.unite.data.enitity.Contact;

/**
 * Created by Manu on 1/8/2017.
 */

public interface UniteDataSource {
    interface LoadContactsCallback {
        void onContactsLoaded(List<Contact> contacts);

        void onContactsNotAvailable();
    }

    void getContacts(@NonNull LoadContactsCallback callback);

    interface LoadContactCallback {
        void onContactLoaded(Contact contact);

        void onContactNotAvailable();
    }

    void getContact(@NonNull LoadContactCallback callback);

    interface SaveContactsCallback {
        void onContactsSavedSuccessful(List<Contact> savedContacts);

        void errorWhileSavingContact(Contact contact);
    }

    void saveContacts(@NonNull List<Contact> contacts, @NonNull SaveContactsCallback callback);

    void refreshPhrases();
}
