package horseman.four.com.unite.data.local;

import android.support.annotation.NonNull;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import horseman.four.com.unite.data.enitity.Contact;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Created by Manu on 1/8/2017.
 */

public class UniteRepository implements UniteDataSource {

    private static UniteRepository INSTANCE = null;

    private UniteDataSource mLocalDataSource;


    private Map<String, Contact> mCachedContacts;


    /**
     * Marks the cache as invalid, to force an update the next time data is requested. This variable
     * has package local visibility so it can be accessed from tests.
     */
    boolean mCacheIsDirty = false;

    // Prevent direct instantiation.
    private UniteRepository(@NonNull UniteDataSource localDataSource) {
        mLocalDataSource = checkNotNull(localDataSource);
    }

    /**
     * Returns the single instance of this class, creating it if necessary.
     *
     * @param localDataSource the device storage data source
     * @return the {@link UniteRepository} instance
     */
    public static UniteRepository getInstance(UniteDataSource localDataSource) {
        if (INSTANCE == null) {
            INSTANCE = new UniteRepository(localDataSource);
        }
        return INSTANCE;
    }


    /**
     * Used to force {@link #getInstance(UniteDataSource)} to create a new
     * instance
     * next time it's called.
     */
    public static void destroyInstance() {
        INSTANCE = null;
    }


    @Override
    public void getContacts(@NonNull final LoadContactsCallback callback) {
        checkNotNull(callback);

        //respond immediately with cache if available and not dirty
        if (mCachedContacts != null && !mCacheIsDirty) {
            callback.onContactsLoaded(new ArrayList<>(mCachedContacts.values()));
            return;
        }

        //check if cache is dirty
        if (mCacheIsDirty) {

            //query local database, if not available query network
            mLocalDataSource.getContacts(new LoadContactsCallback() {
                @Override
                public void onContactsLoaded(List<Contact> contacts) {
                    refreshCache(contacts);
                    callback.onContactsLoaded(new ArrayList<Contact>(mCachedContacts.values()));
                }

                @Override
                public void onContactsNotAvailable() {
                    callback.onContactsNotAvailable();
                }
            });
        }
    }


    private void refreshCache(List<Contact> contacts) {
        if (mCachedContacts == null) {
            mCachedContacts = new LinkedHashMap<>();
        }
        //clear old cached phrase
        mCachedContacts.clear();
        for (Contact contact : contacts) {
            mCachedContacts.put(contact.getPhoneNumber(), contact);
        }
        mCacheIsDirty = false;
    }

    @Override
    public void getContact(@NonNull LoadContactCallback callback) {

    }

    @Override
    public void saveContacts(@NonNull List<Contact> contacts, @NonNull SaveContactsCallback
            callback) {
        checkNotNull(contacts);
        checkNotNull(callback);
        mLocalDataSource.saveContacts(contacts, callback);
        //in memory cache for faster UI update
        for (Contact contact : contacts) {
            mCachedContacts.put(contact.getPhoneNumber(), contact);
        }
    }

    @Override
    public void refreshPhrases() {
        mCacheIsDirty = true;
    }
}
