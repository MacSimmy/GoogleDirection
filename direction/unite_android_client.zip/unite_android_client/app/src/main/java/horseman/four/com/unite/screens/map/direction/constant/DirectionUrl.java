package horseman.four.com.unite.screens.map.direction.constant;

/**
 * Created by Mahendra Chhimwal on 17/1/17.
 */

public class DirectionUrl {
    public static final String MAPS_API_URL = "https://maps.googleapis.com/maps/api/";
    public static final String DIRECTION_API_URL = "directions/json";
}
