package horseman.four.com.unite.screens.map;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.amulyakhare.textdrawable.TextDrawable;
import com.amulyakhare.textdrawable.util.ColorGenerator;

import java.util.List;

import horseman.four.com.unite.R;
import horseman.four.com.unite.screens.map.model.ChatMessage;

/**
 * Created by Mahendra Chhimwal on 20/1/17.
 */

public class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.BaseViewHolder> {

    public static final int OTHER_MESSAGE_TYPE = 0;
    public static final int MY_MESSAGE_TYPE = 1;

    private ColorGenerator generator = ColorGenerator.MATERIAL;

    private Context mContext;
    private List<ChatMessage> mChatList;
    private TextDrawable.IBuilder builder = TextDrawable.builder()
            .beginConfig()
            .withBorder(0)
            .endConfig()
            .round();

    public ChatAdapter(Context context, List<ChatMessage> chatMessages) {
        mContext = context;
        mChatList = chatMessages;
    }

    public void addChatMessage(ChatMessage message) {
        mChatList.add(0,message);
        this.notifyDataSetChanged();
    }


    public void updateChatMessage(List<ChatMessage> messages) {
        mChatList = messages;
        notifyDataSetChanged();
    }

    public void addAllChatMessage(List<ChatMessage> chatMessages) {
        int startPosition = mChatList.size() - 1;
        mChatList.addAll(0,chatMessages);
        this.notifyItemRangeInserted(startPosition, chatMessages.size());
    }

    @Override
    public BaseViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        LayoutInflater inflater = LayoutInflater.from(mContext);
        switch (viewType) {
            case MY_MESSAGE_TYPE:
                view = inflater.inflate(R.layout.item_my_message_view, parent, false);
                return new MyMessageViewHolder(view);
            case OTHER_MESSAGE_TYPE:
                view = inflater.inflate(R.layout.item_others_message_view, parent, false);
                return new OthersMessageViewHolder(view);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(BaseViewHolder holder, int position) {
        ChatMessage message = mChatList.get(position);
        switch (holder.getItemViewType()) {
            case MY_MESSAGE_TYPE:
                ((MyMessageViewHolder) holder).bindChatMessageWIthView(message);
                break;
            case OTHER_MESSAGE_TYPE:
                ((OthersMessageViewHolder) holder).bindChatMessageWIthView(message);
                break;
        }

    }

    @Override
    public int getItemCount() {
        return (mChatList != null) ? mChatList.size() : 0;
    }

    @Override
    public int getItemViewType(int position) {
        ChatMessage chatMessage = mChatList.get(position);
        return chatMessage.isMine() ? MY_MESSAGE_TYPE : OTHER_MESSAGE_TYPE;
    }


    public class BaseViewHolder extends RecyclerView.ViewHolder {
        public BaseViewHolder(View itemView) {
            super(itemView);
        }
    }

    public class OthersMessageViewHolder extends BaseViewHolder {

        private TextView tvMessage;
        private ImageView ivProfile;
        ChatMessage chatMessage;

        public OthersMessageViewHolder(View itemView) {
            super(itemView);
            tvMessage = (TextView) itemView.findViewById(R.id.tv_message);
            ivProfile = (ImageView) itemView.findViewById(R.id.iv_profile);
        }

        public void bindChatMessageWIthView(ChatMessage message) {
            chatMessage = message;
            tvMessage.setText(message.getMessage());
            int color = generator.getRandomColor();
            TextDrawable ic = builder.build("B", color);
            ivProfile.setImageDrawable(ic);
        }
    }

    public class MyMessageViewHolder extends BaseViewHolder {

        private TextView tvMessage;
        private ImageView ivProfile;
        ChatMessage chatMessage;

        public MyMessageViewHolder(View itemView) {
            super(itemView);
            tvMessage = (TextView) itemView.findViewById(R.id.tv_message);
            ivProfile = (ImageView) itemView.findViewById(R.id.iv_profile);
        }

        public void bindChatMessageWIthView(ChatMessage message) {
            chatMessage = message;
            tvMessage.setText(message.getMessage());
            int color = generator.getRandomColor();
            TextDrawable ic = builder.build("A", color);
            ivProfile.setImageDrawable(ic);
        }
    }
}
