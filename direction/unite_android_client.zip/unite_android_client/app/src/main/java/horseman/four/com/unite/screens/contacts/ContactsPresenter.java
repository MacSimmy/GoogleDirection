package horseman.four.com.unite.screens.contacts;


import horseman.four.com.unite.listener.Presenter;


public interface ContactsPresenter extends Presenter {

}
