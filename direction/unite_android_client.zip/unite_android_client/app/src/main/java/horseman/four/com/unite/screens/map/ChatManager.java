package horseman.four.com.unite.screens.map;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.provider.Settings;
import android.support.v7.widget.AppCompatImageButton;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

import java.util.ArrayList;

import horseman.four.com.unite.R;
import horseman.four.com.unite.screens.map.model.ChatMessage;
import horseman.four.com.unite.screens.map.model.ChatModel;
import horseman.four.com.unite.screens.map.mqtt.MqttManager;

/**
 * Created by Mahendra Chhimwal on 19/1/17.
 */

public class ChatManager implements View.OnClickListener {

    private Activity mActivity;

    private View mRootView;
    private EditText mEditChatMessage;
    private AppCompatImageButton mBtnSend;
    private MqttManager mqttManager;
    private ImageButton mBtnCloseChat;
    private RecyclerView mChatList;
    private ChatCallbacks mListener;
    private ChatAdapter mAdapter;
    private  String mClientId ;

    @SuppressLint("HardwareIds")
    public ChatManager(Activity activity, View rootView, MqttManager manager, ChatCallbacks callback) {
        mActivity = activity;
        mRootView = rootView;
        mqttManager = manager;
        mListener = callback;
        mClientId = Settings.Secure.getString(activity.getContentResolver(),
                Settings.Secure.ANDROID_ID);
    }

    public void initChatFramework() {
        initializeViews();
    }

    private void initializeViews() {
        mEditChatMessage = (EditText) mRootView.findViewById(R.id.edit_message);
        mBtnSend = (AppCompatImageButton) mRootView.findViewById(R.id.btn_send);
        mBtnCloseChat = (ImageButton) mRootView.findViewById(R.id.btn_close);
        mChatList = (RecyclerView) mRootView.findViewById(R.id.rv_chat_message);
        LinearLayoutManager layoutManager = new LinearLayoutManager(mActivity, LinearLayoutManager
                .VERTICAL, true);
        mChatList.setLayoutManager(layoutManager);
        mAdapter = new ChatAdapter(mActivity, new ArrayList<ChatMessage>());
        mChatList.setAdapter(mAdapter);
        mBtnCloseChat.setOnClickListener(this);
        mBtnSend.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_send:
                if (mqttManager != null) {
                    String message = mEditChatMessage.getText().toString().trim();
                    if (!message.isEmpty()) {
                        ChatMessage chatMessage = new ChatMessage();
                        chatMessage.setMessage(message);
                        chatMessage.setMine(true);
                        chatMessage.setSenderId("mahendra");
                        chatMessage.setClientId(mClientId);
                        mAdapter.addChatMessage(chatMessage);
                        ChatMessage messageToPublish = new ChatMessage(chatMessage);
                        messageToPublish.setMine(false);
                        String messageText = MqttManager.GSON.toJson(messageToPublish);
                        ChatModel model = new ChatModel();
                        model.setChat(true);
                        model.setSender("Mahendra");
                        model.setMessage(messageText);
                        mqttManager.publishMessage(model);
                        mEditChatMessage.setText("");
                    }
                }
                break;
            case R.id.btn_close:
                if (mListener != null) {
                    mListener.hideChatWindow();
                }
                break;
        }
    }

    public void chatMessageArrived(ChatMessage chatMessage) {
        if (mListener != null) {
            mListener.updateNewChatNotification();
        }
        mAdapter.addChatMessage(chatMessage);
    }

    public interface ChatCallbacks {
        void showChatWindow();

        void hideChatWindow();

        void updateNewChatNotification();
    }

}
