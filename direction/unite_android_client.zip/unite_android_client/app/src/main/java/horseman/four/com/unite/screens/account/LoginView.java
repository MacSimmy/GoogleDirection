package horseman.four.com.unite.screens.account;


import horseman.four.com.unite.utils.AppScreens;
import horseman.four.com.unite.views.BaseView;

/**
 * Created by bhavesh.kumar on 12/18/2016.
 */

public interface LoginView extends BaseView {
    void moveToNextScreen(AppScreens screen, Object object);

    void setEmailError(String error);

    void setPhoneError(String error);

    void setPasswordError(String error);

    void showToastError(String error);
}
