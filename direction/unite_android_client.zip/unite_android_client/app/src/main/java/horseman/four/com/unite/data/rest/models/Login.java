package horseman.four.com.unite.data.rest.models;

import android.util.Log;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Manu on 1/8/2017.
 */

public class Login {
    @SerializedName("userName")
    private String userName;


    @SerializedName("password")
    private String password;

    public Login(String userName,String password){
        this.userName = userName;
        this.password = password;
    }

    public Login(){

    }
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
}
