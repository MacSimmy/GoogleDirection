package horseman.four.com.unite.preference;

/**
 * Created by gurmeet.singh1 on 1/9/2017.
 */

public class LocalStorage {
    public static LocalStorage localStorage = null;
    private String statusValue = null;
    private boolean isApiCall = false;


    private LocalStorage() {
    }

    public static LocalStorage getInstance() {
        if (localStorage == null) {
            synchronized (LocalStorage.class) {
                if (localStorage == null) {
                    localStorage = new LocalStorage();
                }
            }
        }
        return localStorage;
    }

    public void saveStatus(boolean isApiCall) {
        this.isApiCall = isApiCall;
    }

    public boolean getAPIStatus() {
        return isApiCall;
    }

    public void saveLoginStatus(String status) {
        statusValue = status;
    }

    public String getLoginStatus() {
        return statusValue;
    }


}
