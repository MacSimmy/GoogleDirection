package horseman.four.com.unite.service;

import android.app.IntentService;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.provider.ContactsContract;
import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import horseman.four.com.unite.data.enitity.Contact;

/**
 * Created by Manu on 1/7/2017.
 */

public class ContactsReadService extends IntentService {
    private static final String ACTION_INITIAL_CONTACTS_READ = "unite.action.initial_contacts_read";
    private static final String ACTION_REFRESH_CONTACTS = "unite.action.refresh_contacts";

    private static final String IS_FIRST_TIME = "service.extra.IS_FIRST_TIME";

    private List<Contact> mValidContacts = null;
    private HashMap<String, String> mNumberNameMap;

    public ContactsReadService() {
        super("ContactsReadService");
    }

    /**
     * Start reading contacts and sending them to Parse.com for validating user and subscribing them
     * This action also save contacts in personal local sqlite database in a valid schema for Palmtickle.
     *
     * @see IntentService
     */

    public static void startActionReadingInitialContacts(Context context, boolean isFirstTime) {
        Intent intent = new Intent(context, ContactsReadService.class);
        intent.setAction(ACTION_INITIAL_CONTACTS_READ);
        intent.putExtra(IS_FIRST_TIME, isFirstTime);
        context.startService(intent);
    }

    /**
     * Starts this service to perform to perform refresh contacts if any contacts added recently.
     *
     * @see IntentService
     */

    public static void startActionRefreshContacts(Context context) {
        Intent intent = new Intent(context, ContactsReadService.class);
        intent.setAction(ACTION_REFRESH_CONTACTS);
        context.startService(intent);
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        if (intent != null) {
            final String action = intent.getAction();
            if (ACTION_INITIAL_CONTACTS_READ.equals(action)) {
                boolean isFirstTime = intent.getBooleanExtra(IS_FIRST_TIME, false);
                startActionReadContacts(isFirstTime);
                Log.e("ContactsHashMap", mNumberNameMap.toString());
                convertMapToListAndSave();
            } else if (ACTION_REFRESH_CONTACTS.equals(action)) {
                startActionContactsRefresh();
            }
        }else {
            Log.d("","");
        }
    }

    private void convertMapToListAndSave() {
        mValidContacts = new ArrayList<>();
        List<String> phoneNumbers = new ArrayList<>();
        HashMap<String, List<String>> params = new HashMap<>();
        for (Map.Entry<String, String> entry : mNumberNameMap.entrySet()) {
            String phoneNumber = entry.getKey();
            String name = entry.getValue();
            phoneNumbers.add(phoneNumber);
            Contact contact = new Contact(phoneNumber, name);
            mValidContacts.add(contact);
        }

        try {
           // DatabaseBackend.getInstance(this).saveContacts(mValidContacts);
        } catch (Exception e) {
            e.printStackTrace();
        }
        params.put("phoneNumbers", phoneNumbers);

        //call function verifyPhoneNumbers of parse.com
/*
        ParseCloud.callFunctionInBackground("validatePhoneNumbers", params, new FunctionCallback<JSONObject>() {
            public void done(JSONObject response, ParseException e) {
                if (e == null) {
                    Gson gson = new Gson();
                } else {
                    Log.e("PhoneNumbersResponse", "Exception: " + e.toString());
                }
            }
        });*/
    }

    /**
     * Start reading contacts and send them to parse.com
     */
    private void startActionReadContacts(boolean isFirstTime) {
        if (isFirstTime) {
            mNumberNameMap = new HashMap<String, String>();
            ContentResolver cr = getContentResolver();
                                Cursor cur = cr.query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);
                                if (cur != null) {
                                    if (cur.getCount() > 0) {
                                        while (cur.moveToNext()) {
                                            String id = cur.getString(cur.getColumnIndex(ContactsContract.Contacts._ID));
                                            String name = cur.getString(cur.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                                            if (Integer.parseInt(cur.getString(cur.getColumnIndex(ContactsContract.Contacts
                                                    .HAS_PHONE_NUMBER))) > 0) {
                                                Log.e("MyContacts", "name : " + name + ", ID : " + id);
                                                Cursor pCur = cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,
                                                        ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?", new String[]{id}, null);
                                                if (pCur != null) {
                                                    while (pCur.moveToNext()) {
                                                        String phone = pCur.getString(pCur.getColumnIndex(ContactsContract
                                                                .CommonDataKinds.Phone.NUMBER));
                                                        phone = reformatPhoneNumber(phone);
                                                        if (phone != null) {
                                                            Log.e("MyContacts", "phone" + phone);
                                                            String trimmedName = name.trim();
                                                            mNumberNameMap.put(phone, trimmedName);
                                                        }
                                                    }
                                                    pCur.close();
                            }
                        }
                    }
                }
                cur.close();
            }
        }
    }

    private String reformatPhoneNumber(String phone) {
        phone = phone.replaceAll("[^0-9]", "");
        int length = phone.length();
        if (length < 10) {
            //We do not want this number.
            return null;
        } else if (length > 10) {
            //we have to remove extra numbers from starts
            phone = phone.substring(length - 10, length);
            return phone;
        } else {
            //phone number is valid.
            return phone;
        }
    }

    /**
     * Start refreshing latest contacts which are not in Database.
     */

    private void startActionContactsRefresh() {
    }
}