package horseman.four.com.unite.screens.map.mqtt;

import android.annotation.SuppressLint;
import android.content.Context;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.util.Log;

import com.google.gson.Gson;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.util.Arrays;

import horseman.four.com.unite.app.UniteApp;
import horseman.four.com.unite.screens.map.ChatManager;
import horseman.four.com.unite.screens.map.model.ChatMessage;
import horseman.four.com.unite.screens.map.model.ChatModel;

/**
 * Created by Mahendra Chhimwal on 18/1/17.
 */

public class MqttManager implements MqttCallbackExtended {

    public static final String TAG = "MqttManager";

    private MqttAndroidClient mMqttAndroidClient;

    private final String mServerUri = "tcp://unitevm.eastus.cloudapp.azure.com:1883";

    private String mClientId = null;

    private ChatManager mChatManager;
    private Context mContext;
    private String mTopic;

    public static Gson GSON = new Gson();

    private MqttManager() {
        mContext = UniteApp.getContext();
    }

    public static MqttManager getINST() {
        return new MqttManager();
    }

    public void setChatManager(@NonNull ChatManager chatManager) {
        mChatManager = chatManager;
    }

    @SuppressLint("HardwareIds")
    public void initConnection(String topic) {
        mTopic = topic;
        mClientId = Settings.Secure.getString(mContext.getContentResolver(),
                Settings.Secure.ANDROID_ID);
        if (mMqttAndroidClient == null) {
            mMqttAndroidClient = new MqttAndroidClient(mContext, mServerUri, mClientId);
            mMqttAndroidClient.setCallback(this);
        }
        connectToServer();
    }

    @Override
    public void connectComplete(boolean reconnect, String serverURI) {
        if (reconnect) {
            Log.d(TAG, "reconnect is true . So subscribing to topic again");
            // Because Clean Session is true, we need to re-subscribe
            subscribeToTopic();
        } else {
            Log.d(TAG, "Connected to MQTT server");
        }
    }

    private void connectToServer() {
        if (!mMqttAndroidClient.isConnected()) {
            MqttConnectOptions mqttConnectOptions = new MqttConnectOptions();
            mqttConnectOptions.setAutomaticReconnect(true);
            mqttConnectOptions.setCleanSession(false);
            mqttConnectOptions.setKeepAliveInterval(300);
            mqttConnectOptions.setMqttVersion(MqttConnectOptions.MQTT_VERSION_3_1);
            try {
                mMqttAndroidClient.connect(mqttConnectOptions, null, new IMqttActionListener() {
                    @Override
                    public void onSuccess(IMqttToken asyncActionToken) {
                        Log.d(TAG, "mqtt connect successfull. Now Subscribing to topic...");
                        subscribeToTopic();
                    }

                    @Override
                    public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                        if (exception != null) {
                            Log.e(TAG, "connect failure with exception : " + exception.getMessage());
                            exception.printStackTrace();
                        }
                    }
                });

            } catch (MqttException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public void connectionLost(Throwable cause) {
        if (cause != null) {
            Log.e(TAG, "Connection to MQtt is lost due to " + cause.getMessage());
        }
        connectToServer();
    }

    @Override
    public void messageArrived(String topic, MqttMessage message) throws Exception {
        Log.d(TAG, "Message arrived : " + message + " from topic : " + topic);
        if (mTopic.equals(topic)) {
            String text = message.toString();
            if (!TextUtils.isEmpty(text)) {
                handlerChatMessage(text);
            }
        }
    }

    private void handlerChatMessage(String message) {
        try {
            ChatModel chatModel = GSON.fromJson(message, ChatModel.class);
            if (chatModel.isChat()) {
                String chatMessage = chatModel.getMessage();
                if (!TextUtils.isEmpty(chatMessage)) {
                    ChatMessage cMessageObj = GSON.fromJson(chatMessage, ChatMessage.class);
                    if (!mClientId.equals(cMessageObj.getClientId())) {
                        cMessageObj.setMine(false);
                        if (mChatManager != null) {
                            mChatManager.chatMessageArrived(cMessageObj);
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deliveryComplete(IMqttDeliveryToken token) {
        try {
            if (token != null && token.getMessage() != null) {
                Log.d(TAG, "Message : " + token.getMessage().toString() + " delivered");
            }
        } catch (MqttException ex) {
            ex.printStackTrace();
        }
    }


    private void subscribeToTopic() {
        try {
            mMqttAndroidClient.subscribe(mTopic, 0, null, new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Log.d(TAG, "Subscribed to topic : " + mTopic);
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.d(TAG, "topic subscription failed for topic : " + mTopic);
                }
            });

        } catch (MqttException ex) {
            System.err.println("Exception whilst subscribing");
            ex.printStackTrace();
        }
    }


    public void publishMessage(ChatModel chatModel) {

        try {
            String messageText = GSON.toJson(chatModel);
            if (!TextUtils.isEmpty(messageText)) {
                MqttMessage message = new MqttMessage();
                message.setPayload(messageText.getBytes());
                message.setQos(2);
                mMqttAndroidClient.publish(mTopic, message);
                if (!mMqttAndroidClient.isConnected()) {
                    connectToServer();
                }
            }
        } catch (MqttException e) {
            System.err.println("Error Publishing: " + e.getMessage());
            e.printStackTrace();
        }
    }

}
