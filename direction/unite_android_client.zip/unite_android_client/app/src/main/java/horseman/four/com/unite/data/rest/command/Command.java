package horseman.four.com.unite.data.rest.command;

import android.util.Log;

/**
 * Created by Mahendra.Chhimwal.
 * Base class for commands which is an abstraction for commands that can be executed. Just execute these commands  from UI
 * and never call any Rest Service API directly from UI.
 */
public abstract class Command {
    private final String TAG = "UniteCommands";
    private String mCommandName;
    private CommandListener mListener;

    /**
     * Constructor. Build a Command that has no listener.
     */
    public Command() {
        mListener = null;
        this.mCommandName = getClass().getSimpleName();
    }

    /**
     * This constructor will help to provide callback of command success or failure
     * * @param listener
     */
    public Command(CommandListener listener) {
        this.mListener = listener;
        this.mCommandName = getClass().getSimpleName();
    }

    /**
     * This will replace any existing listener with new listener for getting callBacks to commands execution.
     *
     * @param listener
     */
    protected void setListener(CommandListener listener) {
        this.mListener = listener;
    }

    /**
     * Notify the listener (if one was provided) that the Command was run successfully.
     */
    public void notifySuccess() {
        if (mListener != null) {
            Log.d(TAG, this.getClass().getSimpleName() + "::notifySuccess() - fire event to: "
                    + mListener);
            mListener.onCommandSuccess(this);
        }
    }

    /**
     * Notify the listener (if one was provided) that the Command encountered an error.
     *
     * @param e exception
     */
    public void notifyError(Exception e) {
        if (mListener != null) {
            Log.d(TAG, this.getClass().getSimpleName() + "::notifyError() - fire event to: "
                    + mListener);
            mListener.onCommandError(this, e);
        }
    }

    /**
     * Returns name of the current command.
     *
     * @return String Command name.
     */
    public String getCommandName() {
        return mCommandName;
    }

    /**
     * Execute this command. You must provide a listener if you wish to be notified about the
     * success or failure of the Command.
     */
    public abstract void execute();
}
