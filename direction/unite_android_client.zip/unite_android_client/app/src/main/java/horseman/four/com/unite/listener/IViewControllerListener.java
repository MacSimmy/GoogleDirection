package horseman.four.com.unite.listener;

/**
 * Created by bhavesh.kumar on 12/21/2016.
 */

public interface IViewControllerListener {

    void notifyViewOnSuccess(Object object);

    void notifyViewOnFailure(Object object);
}
