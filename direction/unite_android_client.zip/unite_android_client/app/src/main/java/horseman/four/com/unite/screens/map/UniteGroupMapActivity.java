package horseman.four.com.unite.screens.map;

import android.Manifest;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;

import com.amulyakhare.textdrawable.TextDrawable;
import com.aurelhubert.ahbottomnavigation.AHBottomNavigation;
import com.aurelhubert.ahbottomnavigation.AHBottomNavigationItem;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.maps.android.SphericalUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import horseman.four.com.unite.R;
import horseman.four.com.unite.app.UniteApp;
import horseman.four.com.unite.screens.map.direction.DirectionCallback;
import horseman.four.com.unite.screens.map.direction.GoogleDirection;
import horseman.four.com.unite.screens.map.direction.constant.TransportMode;
import horseman.four.com.unite.screens.map.direction.model.Direction;
import horseman.four.com.unite.screens.map.direction.util.DirectionConverter;
import horseman.four.com.unite.screens.map.model.ChatMessage;
import horseman.four.com.unite.screens.map.mqtt.MessageListener;
import horseman.four.com.unite.screens.map.mqtt.MqttManager;
import horseman.four.com.unite.screens.map.mqtt.MqttService;
import horseman.four.com.unite.screens.map.utils.MapUtil;

public class UniteGroupMapActivity extends FragmentActivity implements OnMapReadyCallback, GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener, DirectionCallback,
        LocationListener, MessageListener, ChatManager.ChatCallbacks, GoogleMap.OnMapClickListener, GoogleMap.OnMarkerClickListener, GoogleMap.OnMapLongClickListener {

    public static final String TAG = "UniteGroupMapActivity";
    public static final String mMapServerKey = "AIzaSyAF7ITgi6s_1vtghsYWikIR0MRalr-JDjk";

    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 101;
    private static final long ANIMATION_DURATION = 300;

    private GoogleMap mMap;
    private GoogleApiClient mGoogleApiClient;
    private LocationRequest mLocationRequest;

    private AHBottomNavigation mBottomNavigation;
    private LatLngBounds mCurrentCameraBound = null;

    private Polyline mPolyLines;

    private Marker mDestMarker;
    private Location mCityCenter = new Location("jkbhck");

    private TextDrawable.IBuilder textBuilder = TextDrawable.builder()
            .beginConfig()
            .withBorder(2)
            .bold()
            .textColor(Color.WHITE)
            .fontSize(24)
            .endConfig()
            .round();

    private View mChatFrame;
    private MqttManager mMqttManager;
    private ChatManager mChatManager;
    private Location mCurrentLocation;
    private Location mPreviousLocation;
    private boolean mIsInitialMapSet = false;

    private int mChatMessageCount = 0;
    private HashMap<String, Marker> mUserMarkers = null;
    private boolean mIsChatWindowVisible = false;

    private boolean isWalkingNavActive = true;
    private boolean isPolylineDrawn = false;
    private UniteDualMapActivity.MQTTMessageReceiver messageIntentReceiver;

    private ArrayList<LatLng> mDirectionList = new ArrayList<>();

    private int mMarkerCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unite_dual_map);
        mUserMarkers = new HashMap<>();
        initializeAllViews();
        initializeMap();
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkLocationPermission()) {
                buildGoogleApiClient();
            }
        } else {
            buildGoogleApiClient();
        }
        mMqttManager = MqttManager.getINST();
        mChatManager = new ChatManager(this, mChatFrame, mMqttManager, this);
        mChatManager.initChatFramework();
        mMqttManager.setChatManager(mChatManager);
        mCityCenter.setLatitude(28.5962);
        mCityCenter.setLongitude(77.3396);
    }

    private void initializeMap() {
        GoogleApiAvailability apiAvailability = GoogleApiAvailability.getInstance();
        int resultCode = apiAvailability.isGooglePlayServicesAvailable(this);
        if (resultCode == ConnectionResult.SUCCESS) {
            // Obtain the SupportMapFragment and get notified when the map is ready to be used.
            SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                    .findFragmentById(R.id.map);
            mapFragment.getMapAsync(this);
        } else {
            // Show a custom error message
            apiAvailability.getErrorDialog(this, resultCode, PLAY_SERVICES_RESOLUTION_REQUEST).show();
        }
    }


    @Override
    public void onResume() {
        super.onResume();
        if (mMqttManager == null) {
            mMqttManager = MqttManager.getINST();
        }
        mMqttManager.initConnection("example_topic");
        mMqttManager.setChatManager(mChatManager);
    }

    private void initializeAllViews() {
        mChatFrame = findViewById(R.id.frame_chat);
        mBottomNavigation = (AHBottomNavigation) findViewById(R.id.bottom_navigation);
        setBottomNavigation();
    }


    private void setBottomNavigation() {
        AHBottomNavigationItem tabTransit = new AHBottomNavigationItem(getString(R.string.transit),
                ContextCompat.getDrawable(this, R.drawable.ic_directions_car_black_24dp));
        AHBottomNavigationItem tabChat = new AHBottomNavigationItem(getString(R.string.chat),
                ContextCompat.getDrawable(this, R.drawable.ic_chat_black_24dp));
        AHBottomNavigationItem tabWalking = new AHBottomNavigationItem(getString(R.string
                .walking), ContextCompat.getDrawable(this, R.drawable.ic_directions_walk_black_24dp));

        AHBottomNavigationItem tabReCenter = new AHBottomNavigationItem(getString(R.string
                .recenter), ContextCompat.getDrawable(this, R.drawable
                .ic_center_focus_strong_black_24dp));
        mBottomNavigation.addItem(tabWalking);
        mBottomNavigation.addItem(tabTransit);
        mBottomNavigation.addItem(tabChat);
        mBottomNavigation.addItem(tabReCenter);
        mBottomNavigation.setNotificationBackgroundColor(Color.parseColor("#F63D2B"));
        /*set the coloring effects*/
        mBottomNavigation.setDefaultBackgroundColor(ContextCompat.getColor(this, R.color
                .bottom_navigation_background));
        mBottomNavigation.setTitleState(AHBottomNavigation.TitleState.SHOW_WHEN_ACTIVE);
        mBottomNavigation.setTitleTextSize(getResources().getDimension(R.dimen
                .bottom_active_text_size), getResources().getDimension(R.dimen
                .bottom_inactive_text_size));
        mBottomNavigation.setBehaviorTranslationEnabled(false);
        mBottomNavigation.setAccentColor(ContextCompat.getColor(this, R.color
                .bottom_navigation_accent));
        mBottomNavigation.setInactiveColor(ContextCompat.getColor(this, R.color
                .bottom_navigation_inactive));
        mBottomNavigation.setForceTint(true);
        mBottomNavigation.setColored(false);
        mBottomNavigation.setCurrentItem(isWalkingNavActive ? 0 : 1);
        mBottomNavigation.setUseElevation(true, 2);
        mBottomNavigation.setOnTabSelectedListener(new AHBottomNavigation.OnTabSelectedListener() {
            @Override
            public boolean onTabSelected(int position, boolean wasSelected) {
                switch (position) {
                    case 0:
                        isWalkingNavActive = true;
                        getDirectionWalking();
                        return true;
                    case 1:
                        isWalkingNavActive = false;
                        getDirectionDriving();
                        return true;
                    case 2:
                        showChatWindow();
                        return true;
                    case 3:
                        recenterTheMapCamera();
                        mBottomNavigation.setCurrentItem(isWalkingNavActive ? 0 : 1);
                        return true;
                    default:
                        return true;
                }
            }
        });
    }


    private void recenterTheMapCamera() {
        //update camera position
        if (mMap != null) {
            LatLng currentLatLng = new LatLng(mCurrentLocation.getLatitude(), mCurrentLocation
                    .getLongitude());
            mCurrentCameraBound = LatLngBounds.builder().include(currentLatLng).build();
           /* mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(mCurrentCameraBound
                    .getCenter(), 17));*/
            mMap.animateCamera(CameraUpdateFactory.newLatLngBounds(mCurrentCameraBound, 40), 2000, null);
        }
        mBottomNavigation.setCurrentItem(isWalkingNavActive ? 0 : 1);


    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        MapStyleOptions styleOptions = MapStyleOptions.loadRawResourceStyle(this, R.raw.map_style);
        mMap.setMapStyle(styleOptions);
        mMap.setOnMapClickListener(this);
        mMap.setOnMarkerClickListener(this);
        mMap.setOnMapLongClickListener(this);
    }

    private boolean checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);


            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);
            }
            return false;
        } else {
            return true;
        }
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {

        // request f or location updates
        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(5000);
        mLocationRequest.setFastestInterval(100);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);
        } else {
            checkLocationPermission();
        }
    }

    @Override
    public void onConnectionSuspended(int i) {
        Log.e(TAG, "onConnectionSuspended called with reason " + i);

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        Log.e(TAG, "onConnectionFailed called with reason " + connectionResult.getErrorMessage());
    }

    @Override
    public void onLocationChanged(Location location) {
        Log.d(TAG, "location updated " + location.toString());
        mCurrentLocation = location;
        if (!mIsInitialMapSet) {
            mCurrentLocation = location;
            setInitialMap();
            mIsInitialMapSet = true;
        } else {
            updateCurrentMarker();
        }
        mPreviousLocation = mCurrentLocation;
    }

    private void updateCurrentMarker() {
      /*  try {
            if (!isUserMarkerRemoved && mCurrentLocation != null) {
                LatLng currentLatLng = new LatLng(mCurrentLocation.getLatitude(), mCurrentLocation
                        .getLongitude());
                if (mUserMarker == null && mMap != null) {
                    mUserMarker = mMap.addMarker(new MarkerOptions()
                            .position(currentLatLng)
                            .title("You"));
                }
                if (mUserMarker != null) {
                    mUserMarker.setPosition(currentLatLng);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }*/
    }

    private void setInitialMap() {
        if (mCurrentLocation != null) {
            recenterTheMapCamera();
        }
    }

    private void buildGoogleApiClient() {
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();
        mGoogleApiClient.connect();
        Log.d(TAG, "connecting google Api client");
    }


    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    if (ContextCompat.checkSelfPermission(this,
                            Manifest.permission.ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED) {

                        if (mGoogleApiClient == null) {
                            buildGoogleApiClient();
                        }
                    }

                } else {
                    Log.e(TAG, "User does not provide permission to update location.");
                    Snackbar.make(findViewById(R.id.activity_unite_group_map),
                            "You have to grant permission to update get location updates from device",
                            Snackbar.LENGTH_INDEFINITE).setAction("Update Location", new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            if (checkLocationPermission()) {
                                buildGoogleApiClient();
                            }
                        }
                    });
                }
            }
        }
    }

    @Override
    public void chatMessageArrived(ChatMessage message) {
        Log.d(TAG, "Message Arrived: " + message.getMessage());
    }

    @Override
    public void showChatWindow() {
        if (!mIsChatWindowVisible) {
            mIsChatWindowVisible = true;
            ViewGroup parent = (ViewGroup) mChatFrame.getParent();
            int distance = parent.getHeight() - mChatFrame.getTop();
            AnimatorSet animatorSet = new AnimatorSet();
            animatorSet.setDuration(ANIMATION_DURATION);
            animatorSet.setInterpolator(new DecelerateInterpolator(1));
            mChatFrame.setVisibility(View.VISIBLE);
            animatorSet.playTogether(
                    // ObjectAnimator.ofFloat(mBannerInfoFrame, "alpha", 0, 1),
                    ObjectAnimator.ofFloat(mChatFrame, "translationY", distance, 0));
            animatorSet.start();

            //reset chat message count.
            mChatMessageCount = 0;
            mBottomNavigation.refresh();
            mBottomNavigation.removeAllItems();
            setBottomNavigation();
        }
    }

    @Override
    public void hideChatWindow() {
        if (mIsChatWindowVisible) {
            mIsChatWindowVisible = false;
            ViewGroup parent = (ViewGroup) mChatFrame.getParent();
            int distance = parent.getHeight() - mChatFrame.getTop();
            AnimatorSet animatorSet = new AnimatorSet();
            animatorSet.setDuration(ANIMATION_DURATION);
            animatorSet.setInterpolator(new AccelerateInterpolator(1));
            animatorSet.addListener(new android.animation.Animator.AnimatorListener() {
                @Override
                public void onAnimationStart(android.animation.Animator animation) {

                }

                @Override
                public void onAnimationEnd(android.animation.Animator animation) {
                    mChatFrame.setVisibility(View.GONE);
                    if (isWalkingNavActive) {
                        mBottomNavigation.setCurrentItem(0);
                    } else {
                        mBottomNavigation.setCurrentItem(1);
                    }
                }

                @Override
                public void onAnimationCancel(android.animation.Animator animation) {

                }

                @Override
                public void onAnimationRepeat(android.animation.Animator animation) {

                }
            });
            animatorSet.playTogether(
                    //ObjectAnimator.ofFloat(mBannerInfoFrame, "alpha", 1, 0),
                    ObjectAnimator.ofFloat(mChatFrame, "translationY", 0, distance));
            animatorSet.start();
        }
    }

    @Override
    public void updateNewChatNotification() {
        if (!mIsChatWindowVisible) {
            mChatMessageCount++;
            mBottomNavigation.setNotification(String.valueOf(mChatMessageCount), 2);
        } else {
            mChatMessageCount = 0;
        }
    }

    @Override
    public void onMapClick(LatLng latLng) {

    }

    @Override
    public boolean onMarkerClick(Marker marker) {
        return false;
    }

    @Override
    public void onMapLongClick(LatLng latLng) {

    }


    private void getDirectionWalking() {
        if (!isPolylineDrawn && mCurrentLocation != null) {
            GoogleDirection.withServerKey(mMapServerKey)
                    .from(new LatLng(mCurrentLocation.getLatitude(), mCurrentLocation.getLongitude()))
                    .to(new LatLng(mCityCenter.getLatitude(), mCityCenter.getLongitude()))
                    .transportMode(TransportMode.WALKING)
                    .execute(this);
            clearMarkers();
        }
    }

    private void getDirectionDriving() {
        if (isPolylineDrawn && mCurrentLocation != null) {
            GoogleDirection.withServerKey(mMapServerKey)
                    .from(new LatLng(mCurrentLocation.getLatitude(), mCurrentLocation.getLongitude()))
                    .to(new LatLng(mCityCenter.getLatitude(), mCityCenter.getLongitude()))
                    .transportMode(TransportMode.DRIVING)
                    .execute(this);
        }
    }

    @Override
    public void onDirectionSuccess(Direction direction, String rawBody) {
        if (direction.isOK()) {
           /* mDestMarker = mMap.addMarker(new MarkerOptions().position(new LatLng(mCityCenter.getLatitude(),
                    mCityCenter.getLongitude())).title("Gurmeet")
                    .icon(getMarkerIcon("G"))); */

            ArrayList<LatLng> directionPositionList = direction.getRouteList().get(0).getLegList().get(0).getDirectionPoint();

            if (mPolyLines != null) {
                mPolyLines.remove();
            }
            mDirectionList = directionPositionList;
            mPolyLines = mMap.addPolyline(DirectionConverter.createPolyline(this,
                    directionPositionList, 10,
                    ContextCompat.getColor(this, R.color.color_walking_path)));
            isPolylineDrawn = !isPolylineDrawn;

            ArrayList<LatLng> dirList = new ArrayList<>(mDirectionList);
            MapUtil.fixZoomForLatLngs(mMap, dirList);
            System.out.println("Start anim");
            mAnimator.startAnimation(true, dirList);

            //for destination animation
            ArrayList<LatLng> reverseList = new ArrayList<>(mDirectionList);
            Collections.reverse(reverseList);
            mDestAnimator.startAnimation(true, reverseList);
        }
    }


    private void updateOriginalPolyline() {
        List<LatLng> points = mPolyLines.getPoints();
        if (points != null && points.size() > 0) {
            points.remove(0);
        }
        mPolyLines.setPoints(points);
        checkIfMeet();
    }


    private void updateOriginalPolylineForDest() {
        List<LatLng> points = mPolyLines.getPoints();
        if (points != null && points.size() > 0) {
            points.remove(points.size() - 1);
        }
        mPolyLines.setPoints(points);
        checkIfMeet();
    }

    private void checkIfMeet() {
        List<LatLng> points = mPolyLines.getPoints();
        if (points == null || points.size() == 0) {
            //both have meet together
            mDestAnimator.stopAnimation();
            mAnimator.stopAnimation();
            Snackbar.make(mBottomNavigation, "So .. here are you. Yeah..", Snackbar.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDirectionFailure(Throwable t) {
        Snackbar.make(mBottomNavigation, t.getMessage(), Snackbar.LENGTH_SHORT).show();
    }


    public class MQTTMessageReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle notificationData = intent.getExtras();
            ChatMessage chatMessage = notificationData.getParcelable(MqttService.MQTT_MSG_RECEIVED_MSG);
            mChatManager.chatMessageArrived(chatMessage);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
      /*  Intent svc = new Intent(this, MqttService.class);
        stopService(svc);
        unregisterReceiver(messageIntentReceiver);*/
    }


    /**
     * Important variables for animation
     */

    private Handler mOrigHandler = new Handler();
    private Random mRandom = new Random();
    private Animator mAnimator = new Animator();

    private DestAnimator mDestAnimator = new DestAnimator();
    private final Handler mDestHandler = new Handler();
    private List<Marker> markers = new ArrayList<Marker>();

    private boolean directionsFetched = false;

    /**
     * Clears all markers from the map.
     */
    public void clearMarkers() {
        mMap.clear();
        markers.clear();
    }


    //additional code

    public class Animator implements Runnable {

        private static final int ANIMATE_SPEEED = 1000;
        private static final int ANIMATE_SPEEED_TURN = 1500;
        private static final int BEARING_OFFSET = 20;

        private final Interpolator interpolator = new LinearInterpolator();

        private boolean animating = false;

        private List<LatLng> latLngs = new ArrayList<LatLng>();

        int currentIndex = 0;

        float tilt = 75;
        float zoom = 15.5f;
        boolean upward = true;

        long start = SystemClock.uptimeMillis();

        LatLng endLatLng = null;
        LatLng beginLatLng = null;

        boolean showPolyline = false;

        private Marker trackingMarker;

        public void reset() {
            resetMarkers();
            start = SystemClock.uptimeMillis();
            currentIndex = 0;
            endLatLng = getEndLatLng();
            beginLatLng = getBeginLatLng();

        }

        public void stopAnimation() {
            animating = false;
            mOrigHandler.removeCallbacks(mAnimator);
        }

        public void initialize(boolean showPolyLine) {
            reset();
            this.showPolyline = showPolyLine;

            highLightMarker(0);

            if (showPolyLine) {
                polyLine = initializePolyLine();
            }

            // We first need to put the camera in the correct position for the first run (we need 2 markers for this).....
            LatLng markerPos = latLngs.get(0);
            LatLng secondPos = latLngs.get(1);

            setInitialCameraPosition(markerPos, secondPos);

        }

        private void setInitialCameraPosition(LatLng markerPos,
                                              LatLng secondPos) {

            float bearing = MapUtil.bearingBetweenLatLngs(markerPos, secondPos);
            trackingMarker = mMap.addMarker(new MarkerOptions().position(markerPos)
                    .title("Mahendra")
                    .snippet("Chhimwal").icon(getMarkerIcon("M")));
            trackingMarker.showInfoWindow();

           /* mUserMarker.remove();
            isUserMarkerRemoved = true;*/
            float mapZoom = mMap.getCameraPosition().zoom >= 16 ? mMap.getCameraPosition().zoom : 16;

            CameraPosition cameraPosition =
                    new CameraPosition.Builder()
                            .target(markerPos)
                            //.bearing(bearing + BEARING_OFFSET)
                            .bearing(bearing + BEARING_OFFSET)
                            .tilt(tilt)
                            .zoom(mapZoom)
                            .build();

            mMap.animateCamera(
                    CameraUpdateFactory.newCameraPosition(cameraPosition),
                    ANIMATE_SPEEED_TURN,
                    new GoogleMap.CancelableCallback() {

                        @Override
                        public void onFinish() {
                            System.out.println("finished camera");
                            mAnimator.reset();
                           /* Handler handler = new Handler();
                            handler.post(mAnimator);*/
                            mOrigHandler.post(mAnimator);
                        }

                        @Override
                        public void onCancel() {
                            System.out.println("cancelling camera");
                        }
                    }
            );
        }

        private Polyline polyLine;
        private PolylineOptions rectOptions = new PolylineOptions()
                .width(DirectionConverter.dpToPx(UniteApp.getContext(), 10))
                .color(ContextCompat.getColor(UniteApp.getContext(), R.color.traveled_path_color))
                .geodesic(true)
                .zIndex(1);

        private Polyline initializePolyLine() {
            //polyLinePoints = new ArrayList<LatLng>();
            rectOptions.add(latLngs.get(0));
            return mMap.addPolyline(rectOptions);
        }

        /**
         * Add the marker to the polyline.
         */
        private void updatePolyLine(LatLng latLng) {
            List<LatLng> points = polyLine.getPoints();
            points.add(latLng);
            polyLine.setPoints(points);
        }

        public void startAnimation(boolean showPolyLine, List<LatLng> latLngs) {
            if (trackingMarker != null) {
                trackingMarker.remove();
                stopAnimation();
            }
            this.animating = true;
            this.latLngs = latLngs;
            if (latLngs.size() > 2) {
                initialize(showPolyLine);
            }
        }

        public boolean isAnimating() {
            return this.animating;
        }


        @Override
        public void run() {

            if(isAnimating()) {
                long elapsed = SystemClock.uptimeMillis() - start;
                double t = interpolator.getInterpolation((float) elapsed / ANIMATE_SPEEED);
                LatLng intermediatePosition = SphericalUtil.interpolate(beginLatLng, endLatLng, t);

                Double mapZoomDouble = 18.5 - (Math.abs((0.5 - t)) * 5);
                float mapZoom = mapZoomDouble.floatValue();


                trackingMarker.setPosition(intermediatePosition);

                if (showPolyline) {
                    updatePolyLine(intermediatePosition);
                }

                if (t < 1) {
                    mOrigHandler.postDelayed(this, 16);
                } else {

                    System.out.println("Move to next marker.... current = " + currentIndex + " and size = " + latLngs.size());
                    if (currentIndex < latLngs.size() - 2) {
                        currentIndex++;
                        endLatLng = getEndLatLng();
                        beginLatLng = getBeginLatLng();


                        start = SystemClock.uptimeMillis();

                        Double heading = SphericalUtil.computeHeading(beginLatLng, endLatLng);

                        highLightMarker(currentIndex);

                        CameraPosition cameraPosition =
                                new CameraPosition.Builder()
                                        .target(endLatLng)
                                        .bearing(heading.floatValue() /*+ BEARING_OFFSET*/) // .bearing(bearingL  + BEARING_OFFSET)
                                        .tilt(tilt)
                                        .zoom(mMap.getCameraPosition().zoom)
                                        .build();

                        mMap.animateCamera(
                                CameraUpdateFactory.newCameraPosition(cameraPosition),
                                ANIMATE_SPEEED_TURN,
                                null
                        );

                        updateOriginalPolyline();
                        //start = SystemClock.uptimeMillis();
                        mOrigHandler.postDelayed(this, 16);

                    } else {
                        currentIndex++;
                        highLightMarker(currentIndex);
                        stopAnimation();
                    }

                }
            }
        }


        private LatLng getEndLatLng() {
            return latLngs.get(currentIndex + 1);
        }

        private LatLng getBeginLatLng() {
            return latLngs.get(currentIndex);
        }

    }


    /**
     * Highlight the marker by index.
     */
    private void highLightMarker(int index) {
        if (markers.size() >= index + 1) {
            highLightMarker(markers.get(index));
        }
    }

    /**
     * Highlight the marker by marker.
     */
    private void highLightMarker(Marker marker) {

        if (marker != null) {
            marker.setIcon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE));
            marker.showInfoWindow();
        }

    }

    private void resetMarkers() {
        for (Marker marker : this.markers) {
            marker.setIcon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED));
        }
    }

    private BitmapDescriptor getMarkerIcon(String text) {
        String[] allColors = UniteGroupMapActivity.this.getResources().getStringArray(R.array.colors);
        if (mMarkerCount >= allColors.length) {
            mMarkerCount = 0;
        }
        TextDrawable ic = textBuilder.build(text, Color.parseColor(allColors[mMarkerCount]));
        mMarkerCount++;
        Bitmap bitmap = drawableToBitmap(ic);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }

    public static Bitmap drawableToBitmap(Drawable drawable) {
        if (drawable instanceof BitmapDrawable) {
            return ((BitmapDrawable) drawable).getBitmap();
        }
        int width = drawable.getIntrinsicWidth();
        width = width > 0 ? width : 96; // Replaced the 1 by a 96
        int height = drawable.getIntrinsicHeight();
        height = height > 0 ? height : 96; // Replaced the 1 by a 96

        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);
        return bitmap;
    }

    public class DestAnimator implements Runnable {

        private static final int ANIMATE_SPEEED = 1000;
        private final Interpolator interpolator = new LinearInterpolator();

        private boolean animating = false;

        private List<LatLng> latLngs = new ArrayList<LatLng>();
        int currentIndex = 0;
        long start = SystemClock.uptimeMillis();

        LatLng endLatLng = null;
        LatLng beginLatLng = null;

        boolean showPolyline = false;

        private Marker destTreckMarker;

        public void reset() {
            resetMarkers();
            start = SystemClock.uptimeMillis();
            currentIndex = 0;
            endLatLng = getEndLatLng();
            beginLatLng = getBeginLatLng();

        }

        public void stopAnimation() {
            animating = false;
            mDestHandler.removeCallbacks(mDestAnimator);
        }

        public void initialize(boolean showPolyLine) {
            reset();
            this.showPolyline = showPolyLine;

            highLightMarker(0);
            if (showPolyLine) {
                polyLine = initializePolyLine();
            }

            // We first need to put the camera in the correct position for the first run (we need 2 markers for this).....
            LatLng markerPos = latLngs.get(0);
            LatLng secondPos = latLngs.get(1);
            setInitialCameraPosition(markerPos, secondPos);
        }

        private void setInitialCameraPosition(LatLng markerPos,
                                              LatLng secondPos) {
            destTreckMarker = mMap.addMarker(new MarkerOptions().position(markerPos)
                    .title("Gurnmeet")
                    .icon(getMarkerIcon("G")));
            destTreckMarker.showInfoWindow();
            mDestAnimator.reset();
           /* Handler handler = new Handler();
            handler.post(mDestAnimator);*/
            mDestHandler.post(mDestAnimator);
        }

        private Polyline polyLine;
        private PolylineOptions rectOptions = new PolylineOptions()
                .width(DirectionConverter.dpToPx(UniteApp.getContext(), 10))
                .color(ContextCompat.getColor(UniteApp.getContext(), R.color.traveled_path_color))
                .geodesic(true)
                .zIndex(1);

        private Polyline initializePolyLine() {
            rectOptions.add(latLngs.get(0));
            return mMap.addPolyline(rectOptions);
        }

        /**
         * Add the marker to the polyline.
         */
        private void updatePolyLine(LatLng latLng) {
            List<LatLng> points = polyLine.getPoints();
            points.add(latLng);
            polyLine.setPoints(points);
        }

        public void startAnimation(boolean showPolyLine, List<LatLng> latLngs) {
            if (destTreckMarker != null) {
                destTreckMarker.remove();
                stopAnimation();
            }
            this.animating = true;
            this.latLngs = latLngs;
            if (latLngs.size() > 2) {
                initialize(showPolyLine);
            }
        }

        public boolean isAnimating() {
            return this.animating;
        }


        @Override
        public void run() {
            if(isAnimating()) {
                long elapsed = SystemClock.uptimeMillis() - start;
                double t = interpolator.getInterpolation((float) elapsed / ANIMATE_SPEEED);
                LatLng intermediatePosition = SphericalUtil.interpolate(beginLatLng, endLatLng, t);
                destTreckMarker.setPosition(intermediatePosition);
                if (showPolyline) {
                    updatePolyLine(intermediatePosition);
                }
                if (t < 1) {
                    mDestHandler.postDelayed(this, 30);
                } else {
                    if (currentIndex < latLngs.size() - 2) {
                        currentIndex++;
                        endLatLng = getEndLatLng();
                        beginLatLng = getBeginLatLng();
                        start = SystemClock.uptimeMillis();
                        highLightMarker(currentIndex);
                        updateOriginalPolylineForDest();
                        mDestHandler.postDelayed(this, 60);
                    } else {
                        currentIndex++;
                        highLightMarker(currentIndex);
                        stopAnimation();
                    }
                }
            }
        }


        private LatLng getEndLatLng() {
            return latLngs.get(currentIndex + 1);
        }

        private LatLng getBeginLatLng() {
            return latLngs.get(currentIndex);
        }

    }

}

