package horseman.four.com.unite.screens.map.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Mahendra Chhimwal on 19/1/17.
 */

public class ChatModel {

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isChat() {
        return isChat;
    }

    public void setChat(boolean chat) {
        isChat = chat;
    }

    @SerializedName("message")
    private String message;


    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    @SerializedName("sender")
    private String sender;

    @SerializedName("isChat")
    private boolean isChat;
}
