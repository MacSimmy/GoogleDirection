package horseman.four.com.unite.listener;


import horseman.four.com.unite.mvp.BasePresenter;
import horseman.four.com.unite.pojo.PO.LoginPO;

/**
 * Created by bhavesh.kumar on 12/18/2016.
 */

public interface LoginPresenter extends BasePresenter {

    boolean isValidInput(LoginPO loginPO);

    void doLogin(LoginPO loginPO);

    void onLoginFailed(Object object);

    void onWebServiceFailed(Object object);

}
