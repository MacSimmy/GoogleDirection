package horseman.four.com.unite.screens.account;


import horseman.four.com.unite.app.UniteApp;
import horseman.four.com.unite.listener.IPrefrenceHelperKeys;
import horseman.four.com.unite.listener.ISignUpListener;
import horseman.four.com.unite.network.RestApiBuilder;
import horseman.four.com.unite.network.RestApiServices;
import horseman.four.com.unite.pojo.PO.SignUpPO;
import horseman.four.com.unite.pojo.VO.LoginVO;
import horseman.four.com.unite.utils.AppScreens;
import horseman.four.com.unite.utils.ResponseStatus;
import rx.Subscription;
import rx.subscriptions.CompositeSubscription;

public class SignUpPresenterImpl implements SignUpPresenter, ISignUpListener {
    private final SignUpView view;
    private RestApiServices service;
    private CompositeSubscription subscriptions;

    public SignUpPresenterImpl(SignUpView view) {
        this.view = view;
        this.service = RestApiBuilder.providesService();
        this.subscriptions = new CompositeSubscription();
    }

    public void doSignUp(SignUpPO signUpPO) {
        view.showProgress();
        Subscription subscription = service.doSignUp(this, signUpPO);
        subscriptions.add(subscription);
    }


    @Override
    public void resume() {

    }

    @Override
    public void pause() {

    }

    @Override
    public void stop() {
        subscriptions.unsubscribe();
    }

    @Override
    public void destroy() {

    }

    @Override
    public void notifyViewOnSuccess(Object object) {
        view.hideProgress();
        if (object instanceof LoginVO) {
            if (((LoginVO) object).getStatus() == ResponseStatus.SUCCESS.getValue()) {
                UniteApp.getInstance().getSagoonPref().saveStringValue(IPrefrenceHelperKeys.TOKEN, ((LoginVO) object).getToken());
                UniteApp.getInstance().getSagoonPref().saveStringValue(IPrefrenceHelperKeys.USER_ID, ((LoginVO) object).getUser_id());
                view.moveToNextScreen(AppScreens.SIGNUP);
            } else {
                view.onRegistrationFailed(object);
            }
        }
    }

    @Override
    public void notifyViewOnFailure(Object object) {
        view.hideProgress();
        view.onWebServiceFailed(object);
    }
}
