package horseman.four.com.unite.screens.map.model;

/**
 * Created by Mahendra Chhimwal on 20/1/17.
 */

public class UniteLocation {
    private double mLatitude = 0.0;
    private double mLongitude = 0.0;

    public UniteLocation(){

    }

    public UniteLocation(double latitude, double longitude){
        this.mLatitude = latitude;
        this.mLongitude = longitude;
    }

    public double getLatitude() {
        return mLatitude;
    }

    public void setLatitude(double latitude) {
        this.mLatitude = latitude;
    }

    public double getLongitude() {
        return mLongitude;
    }

    public void setLongitude(double longitude) {
        this.mLongitude = longitude;
    }

}
