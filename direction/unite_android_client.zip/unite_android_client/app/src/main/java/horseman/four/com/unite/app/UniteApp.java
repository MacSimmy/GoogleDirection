package horseman.four.com.unite.app;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import java.util.ArrayList;

import horseman.four.com.unite.preference.PreferenceHelper;
import horseman.four.com.unite.screens.account.BaseActivity;
import horseman.four.com.unite.screens.account.LoginActivity;
import horseman.four.com.unite.screens.account.SignUpActivity;
import horseman.four.com.unite.screens.contacts.ContactsActivity;
import horseman.four.com.unite.screens.map.mqtt.MqttManager;
import horseman.four.com.unite.utils.AppScreens;
import horseman.four.com.unite.utils.ConstantValues;

/**
 * Created by Manu on 1/7/2017.
 */

public class UniteApp extends Application {
    private static UniteApp mInstance;
    BaseActivity foregroundActivity;

    public MqttManager getmMqttManager() {

        return mMqttManager;
    }

    public void startMqttManager(){

    }

    public void setmMqttManager(MqttManager mMqttManager) {
        this.mMqttManager = mMqttManager;
    }

    private MqttManager mMqttManager;

    private PreferenceHelper mSagoonPref;

    public static UniteApp getInstance() {
        synchronized (UniteApp.class) {
            if (mInstance == null) {
                mInstance = new UniteApp();
            }
        }
        return mInstance;
    }

    public static Context getContext() {
        return mInstance.getApplicationContext();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        init();
        mSagoonPref = new PreferenceHelper(mInstance);
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
    }

    private void init() {
        mInstance = this;
    }

    public PreferenceHelper getSagoonPref() {
        return mSagoonPref;
    }

    @Override
    public void onLowMemory() {
        System.gc();
        super.onLowMemory();
    }


    public BaseActivity getForegroundActivity() {
        return foregroundActivity;
    }

    public void setForegroundActivity(BaseActivity foregroundActivity) {
        this.foregroundActivity = foregroundActivity;
    }

    public void startActivity(AppScreens screen) {
        startActivity(screen, null, false);
    }

    public void startActivity(AppScreens screen, boolean finish) {
        startActivity(screen, null, finish);
    }

    public void startActivity(AppScreens screen, Bundle bundle, boolean finish) {
        Intent intent = null;
        switch (screen) {
            case SIGNIN:
                intent = new Intent(getForegroundActivity(), LoginActivity.class);
                break;

            case SIGNUP:
                intent = new Intent(getForegroundActivity(), SignUpActivity.class);
                break;
            case CONTACTS:
                intent = new Intent(getForegroundActivity(), ContactsActivity.class);
                break;



            /*if (int
            ent != null) {
                if (bundle != null)
                    intent.putExtra(ConstantValues.BUNDLE_DATA, bundle);

                getForegroundActivity().startActivity(intent);
                if (finish)
                    getForegroundActivity().finish();
            }*/
        }
        getForegroundActivity().startActivity(intent);
        if (finish)
            getForegroundActivity().finish();
    }
}

