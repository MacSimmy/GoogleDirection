package horseman.four.com.unite.screens.map.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Mahendra Chhimwal on 19/1/17.
 */

public class ChatMessage implements Parcelable {


    public ChatMessage() {

    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    private String clientId;

    public ChatMessage(ChatMessage message) {
        this.message = message.getMessage();
        this.senderId = message.getSenderId();
        this.isMine = message.isMine();
        this.clientId = message.getClientId();
    }

    protected ChatMessage(Parcel in) {
        message = in.readString();
        senderId = in.readString();
        isMine = in.readByte() != 0;
        clientId = in.readString();
    }

    public static final Creator<ChatMessage> CREATOR = new Creator<ChatMessage>() {
        @Override
        public ChatMessage createFromParcel(Parcel in) {
            return new ChatMessage(in);
        }

        @Override
        public ChatMessage[] newArray(int size) {
            return new ChatMessage[size];
        }
    };

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    private String message;

    private String senderId;

    public boolean isMine() {
        return isMine;
    }

    public void setMine(boolean mine) {
        isMine = mine;
    }

    private boolean isMine = false;

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(message);
        dest.writeString(senderId);
        dest.writeByte((byte) (isMine ? 1 : 0));
        dest.writeString((clientId == null) ? " " : clientId);
    }
}
