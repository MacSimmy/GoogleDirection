package horseman.four.com.unite.data.rest.client;


import horseman.four.com.unite.data.rest.models.Login;
import horseman.four.com.unite.data.rest.models.Profile;
import horseman.four.com.unite.data.rest.models.User;
import horseman.four.com.unite.screens.map.direction.constant.DirectionUrl;
import horseman.four.com.unite.screens.map.direction.model.Direction;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

/**
 * Created by Mahendra.Chhimwal
 */
public interface UniteService {
    @GET("unite/api/user/{userId}")
    Call<Profile> getProfile(@Path("userId") String owner);

    @POST("/unite/api/user/login")
    Call<User> login(@Body Login login);
}
