package horseman.four.com.unite.screens.map.mqtt;

import horseman.four.com.unite.data.rest.models.Message;
import horseman.four.com.unite.screens.map.model.ChatMessage;

/**
 * Created by Mahendra Chhimwal on 19/1/17.
 */

public interface MessageListener {

    void chatMessageArrived(ChatMessage message);
}
