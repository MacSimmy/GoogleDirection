package horseman.four.com.unite.screens.map.direction.constant;

/**
 * Created by Mahendra Chhimwal on 17/1/17.
 */

public class TransitMode {
    public static final String BUS = "bus";
    public static final String SUBWAY = "subway";
    public static final String TRAIN = "train";
    public static final String TRAM = "tram";
    public static final String RAIL = "rail";
}

