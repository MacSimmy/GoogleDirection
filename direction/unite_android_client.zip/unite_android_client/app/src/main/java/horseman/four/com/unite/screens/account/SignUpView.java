package horseman.four.com.unite.screens.account;


import horseman.four.com.unite.utils.AppScreens;
import horseman.four.com.unite.views.BaseView;

/**
 * Created by naresh.kaushik on 12/23/2016.
 */

public interface SignUpView extends BaseView {

    boolean isValidInput();

    void moveToNextScreen(AppScreens screen);

    void onRegistrationFailed(Object object);

    void onWebServiceFailed(Object object);
}
