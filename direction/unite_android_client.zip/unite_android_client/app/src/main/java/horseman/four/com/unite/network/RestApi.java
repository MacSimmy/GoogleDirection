package horseman.four.com.unite.network;

/**
 * Created by bhavesh.kumar on 12/15/2016.
 */


import horseman.four.com.unite.pojo.PO.LoginPO;
import horseman.four.com.unite.pojo.PO.SignUpPO;
import horseman.four.com.unite.pojo.VO.LoginVO;
import retrofit2.http.Body;
import retrofit2.http.POST;
import rx.Observable;

public interface RestApi {

    String API_BASE_URL = "";

    @POST("/Login/loginUser")
    Observable<LoginVO> login(@Body LoginPO loginPO);

    @POST("/Login/loginUser")
    Observable<LoginVO> doSignUp(@Body SignUpPO signUpPO);


}
