package horseman.four.com.unite.pojo.PO;

import horseman.four.com.unite.app.UniteApp;
import horseman.four.com.unite.listener.IPrefrenceHelperKeys;



public class BasePO {
    private String token;

    public BasePO() {
        String token = UniteApp.getInstance().getSagoonPref().getStringValue(IPrefrenceHelperKeys.TOKEN);
        setToken(token);
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
