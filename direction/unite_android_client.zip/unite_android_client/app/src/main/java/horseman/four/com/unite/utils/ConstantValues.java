package horseman.four.com.unite.utils;


public interface ConstantValues {

    String PHONE = "phone";
    String BUNDLE_DATA = "BUNDLE_DATA";
}
