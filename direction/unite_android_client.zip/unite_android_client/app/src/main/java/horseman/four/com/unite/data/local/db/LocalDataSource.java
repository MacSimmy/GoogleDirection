package horseman.four.com.unite.data.local.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.annotation.NonNull;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import horseman.four.com.unite.data.enitity.Contact;
import horseman.four.com.unite.data.local.UniteDataSource;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Created by Manu on 1/8/2017.
 */

public class LocalDataSource implements UniteDataSource {
    private static LocalDataSource INSTANCE;

    private UniteDBHelper mDbHelper;

    private LocalDataSource(@NonNull Context context) {
        checkNotNull(context);
        mDbHelper = new UniteDBHelper(context);
    }

    public static LocalDataSource getInstance(@NonNull Context context) {
        if (INSTANCE == null) {
            INSTANCE = new LocalDataSource(context);
        }
        return INSTANCE;
    }


    @Override
    public void getContacts(@NonNull LoadContactsCallback callback) {
        checkNotNull(callback);
        List<Contact> contacts = new ArrayList<>();
        SQLiteDatabase db = mDbHelper.getReadableDatabase();

        Cursor cursor;
        cursor = db.query(Contact.TABLE_NAME, null, null, null, null, null, null);
        if (cursor != null && cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                Contact contact = Contact.fromCursor(cursor);
                contacts.add(contact);
            }
        }
        if (cursor != null) {
            cursor.close();
        }
        db.close();
        if (contacts.isEmpty()) {
            callback.onContactsNotAvailable();
        } else {
            callback.onContactsLoaded(contacts);
        }
    }

    @Override
    public void getContact(@NonNull LoadContactCallback callback) {

    }

    @Override
    public void saveContacts(@NonNull List<Contact> contacts, @NonNull SaveContactsCallback
            callback) {
        checkNotNull(contacts);
        checkNotNull(callback);
        SQLiteDatabase db = mDbHelper.getWritableDatabase();
        for (int i = 0; i < contacts.size(); i++) {
            Contact contact = contacts.get(i);
            ContentValues values = contact.getContentValues();
            db.insert(Contact.TABLE_NAME, null, values);
            Log.e(this.getClass().getSimpleName(), "inserted : " + contact.getPhoneNumber() +
                    contact.getDisplayName());
        }
        db.close();
    }

    @Override
    public void refreshPhrases() {
        //empty for now
    }
}
