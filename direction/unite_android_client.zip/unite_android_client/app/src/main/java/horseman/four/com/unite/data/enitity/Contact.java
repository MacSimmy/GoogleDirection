package horseman.four.com.unite.data.enitity;

import android.content.ContentValues;
import android.database.Cursor;

import java.util.Date;

/**
 * Created by Manu on 1/7/2017.
 */

public class Contact extends AbstractEntity {
    public static final String TABLE_NAME = "contacts";

    public static final String PHONE_NUMBER = "phone_number";
    public static final String NAME = "name";
    public static final String ACCOUNT = "accountUuid";
    public static final String USER_ID = "user_id";
    public static final String IS_GROUP = "is_group";
    public static final String PROFILE_PHOTO_URI = "profile_photo_uri";
    public static final String CREATED_AT = "createdAt";

    private String phoneNumber;
    private String displayName;
    private String accountId;
    private String userId;
    private boolean isGroup;
    private String profilePhotoUri;
    private Date createdAt;

    public Contact(String phoneNumber, String name) {
        this.phoneNumber = phoneNumber;
        this.displayName = name;
        createdAt = new Date();
    }


    public Contact(String phoneNumber, String name, String accountId, boolean isGroup, String
            profilePhotoUri, long timeStamp) {
        this.phoneNumber = phoneNumber;
        this.displayName = name;
        this.accountId = accountId;
        this.isGroup = isGroup;
        this.profilePhotoUri = profilePhotoUri;
        this.createdAt = new Date(timeStamp);
    }

    @Override
    public ContentValues getContentValues() {
        ContentValues values = new ContentValues();
        values.put(PHONE_NUMBER, phoneNumber);
        values.put(NAME, displayName);
        values.put(ACCOUNT, accountId);
        values.put(IS_GROUP, isGroup);
        values.put(PROFILE_PHOTO_URI, profilePhotoUri);
        values.put(CREATED_AT, createdAt.getTime());
        return values;
    }

    public static Contact fromCursor(final Cursor cursor) {
        if (cursor != null) {
            return new Contact(cursor.getString(cursor.getColumnIndex(PHONE_NUMBER)), cursor
                    .getString(cursor.getColumnIndex(NAME)), cursor.getString(cursor
                    .getColumnIndex(ACCOUNT)), cursor.getInt(cursor.getColumnIndex(IS_GROUP)) >
                    0, cursor.getString(cursor.getColumnIndex(PROFILE_PHOTO_URI)), cursor.getLong
                    (cursor.getColumnIndex(CREATED_AT)));
        } else return null;
    }


    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public boolean isGroup() {
        return isGroup;
    }

    public void setGroup(boolean group) {
        isGroup = group;
    }

    public String getProfilePhotoUri() {
        return profilePhotoUri;
    }

    public void setProfilePhotoUri(String profilePhotoUri) {
        this.profilePhotoUri = profilePhotoUri;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }
}

