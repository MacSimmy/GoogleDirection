package horseman.four.com.unite.screens.contacts;


import horseman.four.com.unite.listener.IViewControllerListener;
import horseman.four.com.unite.network.RestApiBuilder;
import horseman.four.com.unite.network.RestApiServices;
import horseman.four.com.unite.pojo.PO.ImportedContactPO;


public class ContactPresenterImpl implements ContactsPresenter,IViewControllerListener {
    RestApiServices restApiServices;

    public ContactPresenterImpl() {
        restApiServices = RestApiBuilder.providesService();
    }

  /*  @Override
    public void getImportedContacts(ImportedContactPO importedContactPO) {
        restApiServices.getContactsImported(this,importedContactPO);
    }*/

    @Override
    public void resume() {

    }

    @Override
    public void pause() {

    }

    @Override
    public void stop() {

    }

    @Override
    public void destroy() {

    }

    @Override
    public void notifyViewOnSuccess(Object object) {

    }

    @Override
    public void notifyViewOnFailure(Object object) {

    }
}
