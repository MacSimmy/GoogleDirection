package horseman.four.com.unite.views;



public interface BaseView {
    void showProgress();

    void hideProgress();


}
