package horseman.four.com.unite.screens.contacts;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import com.squareup.picasso.Picasso;

import java.lang.annotation.Target;
import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;
import horseman.four.com.unite.R;

/**
 * Created by gurmeet.singh1 on 1/12/2017.
 */

public class ContactAdapter extends RecyclerView.Adapter<ContactAdapter.ViewHolder> {

    private Context mContext;
    private ArrayList<ContactListData> mContactListData;

    public ContactAdapter(Context context, ArrayList<ContactListData> contactListData) {
        this.mContext = context;
        this.mContactListData = contactListData;
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.adapter_contact_item, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.nameTextView.setText(mContactListData.get(position).getName());
        holder.categoryTextView.setText(mContactListData.get(position).getCategory());
        holder.phonenoTextView.setText(mContactListData.get(position).getPhoneno());
        Picasso.with(mContext).load(mContactListData.get(position).getUrl())
                .placeholder(R.mipmap.ic_launcher)
                .error(R.mipmap.ic_launcher)
                .centerCrop()
                .resize(50, 50)
                .into(holder.circleImageView);
    }

    @Override
    public int getItemCount() {
        return mContactListData.size() > 0 ? mContactListData.size() : 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView nameTextView, categoryTextView, phonenoTextView;
        private CircleImageView circleImageView;

        public ViewHolder(View view) {
            super(view);
            nameTextView = (TextView) view.findViewById(R.id.name_tv);
            categoryTextView = (TextView) view.findViewById(R.id.category_tv);
            phonenoTextView = (TextView) view.findViewById(R.id.phone_tv);
            circleImageView = (CircleImageView) view.findViewById(R.id.image_view);
        }
    }


    void loadImage(Context context, String url) {

    }
}
