package horseman.four.com.unite.data.local.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import horseman.four.com.unite.data.enitity.Contact;

/**
 * Created by Manu on 1/8/2017.
 */

public class UniteDBHelper extends SQLiteOpenHelper {

    public static final int DATABASE_VERSION = 1;

    public static final String DATABASE_NAME = "Unite.db";

    private static final String TEXT_TYPE = " TEXT";

    private static final String INTEGER_TYPE = " INTEGER";

    private static final String DATE_TIME_TYPE = " DATETIME";

    private static final String COMMA_SEP = ",";

    static String SQL_CREATE_ENTRIES = "CREATE TABLE " +
            Contact.TABLE_NAME + "(" +
            Contact.ACCOUNT + TEXT_TYPE + COMMA_SEP + Contact.PHONE_NUMBER + TEXT_TYPE + COMMA_SEP +
            Contact.NAME + TEXT_TYPE + COMMA_SEP +
            Contact.USER_ID + TEXT_TYPE + COMMA_SEP +
            Contact.CREATED_AT + DATE_TIME_TYPE + COMMA_SEP +
            " )";


    public UniteDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        Log.d("UniteDBHelper", SQL_CREATE_ENTRIES);
        sqLiteDatabase.execSQL(SQL_CREATE_ENTRIES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + Contact.TABLE_NAME);
        onCreate(sqLiteDatabase);
    }

    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Not required as at version 1
    }
}
