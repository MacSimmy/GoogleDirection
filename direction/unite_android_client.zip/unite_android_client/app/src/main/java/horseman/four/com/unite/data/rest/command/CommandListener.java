package horseman.four.com.unite.data.rest.command;

/**
 * Created by Mahendra.Chhimwal .
 * Defines an interface for a CommandListener to implement.
 */

public interface CommandListener {

    public void onCommandSuccess(Command c);

    public void onCommandError(Command c, Exception e);
}