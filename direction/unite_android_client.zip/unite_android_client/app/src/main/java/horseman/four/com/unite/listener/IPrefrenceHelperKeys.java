package horseman.four.com.unite.listener;

/**
 * Created by gurmeet.singh1 on 12/28/2016.
 */

public interface IPrefrenceHelperKeys {

    String APP_PREFERENCE = "UnitePreference";
    String USER_LOGIN_INFO = "userloginDetails";
    String PREFS_FILE_NAME = "unite_prefrence_file";
    String USER_ID = "user_id";
    String VERIFICATION_KEY = "verification_key";
    String TOKEN = "token";
    String ON_BOARDING_SCREEN_NUMBER = "ON_BOARDING_SCREEN_NUMBER";
    String LOGIN_TYPE = "login_type";
    String IS_OTP_COMMING_STATUS = "is_otp_comming_status";
}
