package horseman.four.com.unite.preference;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;

import horseman.four.com.unite.listener.IPrefrenceHelperKeys;
import horseman.four.com.unite.pojo.PO.LoginPO;

public class PreferenceHelper {
    public static PreferenceHelper appPrefrence = null;
    private final Context mContext;
    private Gson gson;
    private SharedPreferences preferences = null;

    public PreferenceHelper(Context context) {
        preferences = context.getSharedPreferences(IPrefrenceHelperKeys.PREFS_FILE_NAME, Context.MODE_PRIVATE);
        this.mContext = context;
    }

    public static PreferenceHelper getAppPrefs(Context context) {
        if (appPrefrence == null) {
            synchronized (PreferenceHelper.class) {
                if (appPrefrence == null)
                    appPrefrence = new PreferenceHelper(context);
            }
        }
        return appPrefrence;
    }

    private Gson getGson() {
        if (gson == null) {
            gson = new Gson();
        }
        return gson;
    }


    public void saveUserInfo(LoginPO loginPO) {
        SharedPreferences.Editor editor = preferences.edit();
        String json = getGson().toJson(loginPO);
        editor.putString(IPrefrenceHelperKeys.USER_LOGIN_INFO, json);
        editor.apply();
    }

    public void removeUserInfo() {
        SharedPreferences.Editor editor = preferences.edit();
        editor.remove(IPrefrenceHelperKeys.USER_LOGIN_INFO);
        editor.apply();
    }

    public void saveStringValue(String key, String value) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(key, value);
        editor.apply();
    }

    public int getIntValue(String key) {
        return preferences.getInt(key, -1);
    }

    public void saveIntValue(String key, int value) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(key, value);
        editor.commit();
    }

    public String getStringValue(String key) {
        return preferences.getString(key, "");
    }


    public void saveBooleanValue(String key, boolean value) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean(key, value);
        editor.commit();
    }

    public boolean getBooleanValue(String key) {
        return preferences.getBoolean(key, false);
    }


}
