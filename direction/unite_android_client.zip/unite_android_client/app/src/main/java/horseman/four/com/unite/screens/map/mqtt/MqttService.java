package horseman.four.com.unite.screens.map.mqtt;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

import horseman.four.com.unite.data.rest.models.Message;
import horseman.four.com.unite.screens.map.model.ChatMessage;

public class MqttService extends Service implements MessageListener {
    public static final java.lang.String MQTT_MSG_RECEIVED_TOPIC = "horseman.four.com.unite.topic";
    public static final java.lang.String MQTT_MSG_RECEIVED_MSG = "horseman.four.com.unite.message";
    public static final String MQTT_MSG_RECEIVED_INTENT = "horseman.four.com.unite.message.received";

    private MqttManager mMqttManager;

    private String mTopicId;
    public MqttService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public void broadcastReceivedMessage(ChatMessage message) {
        Intent broadcastIntent = new Intent();
        broadcastIntent.setAction(MQTT_MSG_RECEIVED_INTENT);
        broadcastIntent.putExtra(MQTT_MSG_RECEIVED_MSG, message);
        sendBroadcast(broadcastIntent);
    }

    @Override
    public void chatMessageArrived(ChatMessage message) {
        broadcastReceivedMessage(message);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // disconnect immediately
        disconnectFromBroker();

    }

    @Override
    public void onCreate() {
        super.onCreate();
        mMqttManager = MqttManager.getINST();
        checkConnectionAndReconnect();
    }


    @Override
    public int onStartCommand(final Intent intent, int flags, final int startId) {
        checkConnectionAndReconnect();
        return START_STICKY;
    }

    private void checkConnectionAndReconnect() {
         if(mMqttManager == null){
             mMqttManager = MqttManager.getINST();
         }

        mMqttManager.initConnection("");
    }

    private void disconnectFromBroker() {

    }

}
