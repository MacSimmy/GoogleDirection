package horseman.four.com.unite.data.rest.client;

import horseman.four.com.unite.app.AppConfig;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


/**
 * Created by Mahendra.Chhimwal on 08-Jan-16.
 */
public class RestClient {

    private UniteService apiService;

    private static RestClient me = new RestClient();


    private RestClient() {
        Retrofit retrofit = new Retrofit.Builder().baseUrl(AppConfig.SERVICE_BASE_URL)
                .addConverterFactory(GsonConverterFactory.create()).build();

        apiService = retrofit.create(UniteService.class);
    }

    public UniteService getApiService() {
        return apiService;
    }

    public static RestClient getRestClient() {
        return me;
    }
}