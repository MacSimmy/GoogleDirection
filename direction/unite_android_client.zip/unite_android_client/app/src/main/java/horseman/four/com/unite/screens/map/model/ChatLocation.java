package horseman.four.com.unite.screens.map.model;

/**
 * Created by Mahendra Chhimwal on 20/1/17.
 */

public class ChatLocation {

    public UniteLocation getLocation() {
        return location;
    }

    public void setLocation(UniteLocation location) {
        this.location = location;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    private UniteLocation location;

    private String userId;
}
