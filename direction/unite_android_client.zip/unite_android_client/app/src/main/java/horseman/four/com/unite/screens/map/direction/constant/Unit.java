package horseman.four.com.unite.screens.map.direction.constant;

/**
 * Created by Mahendra Chhimwal on 17/1/17.
 */

public class Unit {
    public static final String METRIC = "metric";
    public static final String IMPERIAL = "imperial";

}
