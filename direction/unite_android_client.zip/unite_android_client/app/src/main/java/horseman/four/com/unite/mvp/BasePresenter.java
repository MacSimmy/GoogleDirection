package horseman.four.com.unite.mvp;

/**
 * Created by mahendra.chhimwal on 9/29/2016.
 */

public interface BasePresenter {

    void start();

    void onScreenStopped();

    void onScreenCreated();

    void onScreenResumed();
}
