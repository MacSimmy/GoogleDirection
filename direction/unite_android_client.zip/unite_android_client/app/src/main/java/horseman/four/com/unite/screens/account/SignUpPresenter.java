package horseman.four.com.unite.screens.account;


import horseman.four.com.unite.listener.Presenter;
import horseman.four.com.unite.pojo.PO.SignUpPO;

/**
 * Created by bhavesh.kumar on 12/18/2016.
 */

public interface SignUpPresenter extends Presenter {

    void doSignUp(SignUpPO signUpPO);
}
