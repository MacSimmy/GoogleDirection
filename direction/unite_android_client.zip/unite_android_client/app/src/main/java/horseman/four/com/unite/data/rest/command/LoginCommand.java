package horseman.four.com.unite.data.rest.command;

import android.text.TextUtils;

import horseman.four.com.unite.data.rest.client.RestClient;
import horseman.four.com.unite.data.rest.models.Login;
import horseman.four.com.unite.data.rest.models.User;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Manu on 1/8/2017.
 */

public class LoginCommand extends Command {

    private String userName;
    private String password;

    private User user;

    public LoginCommand(String userName, String password, CommandListener listener) {
        super(listener);
        this.userName = userName;
        this.password = password;
    }

    @Override
    public void execute() {
        if (!TextUtils.isEmpty(userName) && !TextUtils.isEmpty(password)) {
            Login login = new Login(userName, password);

            RestClient.getRestClient().getApiService().login(login).enqueue(new Callback<User>() {
                @Override
                public void onResponse(Call<User> call, Response<User> response) {
                    if (response.isSuccessful() && response.body() != null) {
                        user = response.body();
                        notifySuccess();
                    } else {
                        notifyError(new Exception("Empty response body"));
                    }
                }

                @Override
                public void onFailure(Call<User> call, Throwable t) {
                    notifyError(new Exception(t));
                }
            });
        } else {
            notifyError(new Exception("Empty username or empty password"));
        }
    }

    private User getUser() {
        return user;
    }
}
