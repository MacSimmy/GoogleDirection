package horseman.four.com.unite.screens.home;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import horseman.four.com.unite.screens.account.BaseActivity;
import horseman.four.com.unite.screens.account.LoginActivity;
import horseman.four.com.unite.screens.map.UniteDualMapActivity;
import horseman.four.com.unite.screens.map.UniteGroupMapActivity;

/**
 * Created by Bharat Bhushan on 14-01-2017.
 */

public class SplashActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                launchScreen();
            }
        },100);
    }

    private void launchScreen() {
        Intent intent = new Intent(SplashActivity.this, UniteGroupMapActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onPause() {
        super.onPause();

    }

    @Override
    protected void onDestroy() {

        super.onDestroy();

    }


}
