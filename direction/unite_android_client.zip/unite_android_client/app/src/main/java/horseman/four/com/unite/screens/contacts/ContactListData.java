package horseman.four.com.unite.screens.contacts;

/**
 * Created by gurmeet.singh1 on 1/12/2017.
 */
public class ContactListData {
    private String name;
    private String category;
    private String phoneno;
    private String url;

    public ContactListData(String name, String phoneno, String category,String url) {
        this.name = name;
        this.phoneno = phoneno;
        this.category = category;
        this.url = url;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getPhoneno() {
        return phoneno;
    }

    public void setPhoneno(String phoneno) {
        this.phoneno = phoneno;
    }
}
