package horseman.four.com.unite.network;


import horseman.four.com.unite.listener.ILoginListener;
import horseman.four.com.unite.listener.ISignUpListener;
import horseman.four.com.unite.pojo.PO.LoginPO;
import horseman.four.com.unite.pojo.PO.SignUpPO;
import horseman.four.com.unite.pojo.VO.LoginVO;
import rx.Observable;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

/**
 * Created by bhavesh.kumar on 12/15/2016.
 */

public class RestApiServices {
    private final RestApi restAPI;

    public RestApiServices(RestApi restAPI) {
        this.restAPI = restAPI;
    }

    public Subscription getLoginInfo(final ILoginListener callback, LoginPO loginPO) {

        return restAPI.login(loginPO)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .onErrorResumeNext(new Func1<Throwable, Observable<? extends LoginVO>>() {
                    @Override
                    public Observable<? extends LoginVO> call(Throwable throwable) {
                        return Observable.error(throwable);
                    }
                })
                .subscribe(new Subscriber<LoginVO>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        callback.notifyViewOnFailure(new NetworkError(e));

                    }

                    @Override
                    public void onNext(LoginVO loginVO) {
                        callback.notifyViewOnSuccess(loginVO);

                    }
                });
    }

    public Subscription doSignUp(final ISignUpListener callback, SignUpPO signUpPO) {

        return restAPI.doSignUp(signUpPO)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .onErrorResumeNext(new Func1<Throwable, Observable<? extends LoginVO>>() {
                    @Override
                    public Observable<? extends LoginVO> call(Throwable throwable) {
                        return Observable.error(throwable);
                    }
                })
                .subscribe(new Subscriber<LoginVO>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        callback.notifyViewOnFailure(new NetworkError(e));

                    }

                    @Override
                    public void onNext(LoginVO loginVO) {
                        callback.notifyViewOnSuccess(loginVO);

                    }
                });
    }
}
