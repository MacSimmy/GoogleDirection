package horseman.four.com.unite.screens.map.direction.constant;

/**
 * Created by Mahendra Chhimwal on 17/1/17.
 */

public class TransportMode {
    public static final String DRIVING = "driving";
    public static final String WALKING = "walking";
    public static final String BICYCLING = "bicycling";
    public static final String TRANSIT = "transit";
}

