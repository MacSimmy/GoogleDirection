package horseman.four.com.unite.data.rest.models;

/**
 * Created by Manu on 1/8/2017.
 */

public class Profile {
}
