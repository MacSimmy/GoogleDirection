package horseman.four.com.unite.pojo.PO;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by Naresh.Kaushik on 1/13/2017.
 */

public class ImportedContactPO extends BasePO{

    @SerializedName("search_keyword")
    @Expose
    private String searchKeyword;
    @SerializedName("after_contact_id")
    @Expose
    private String afterContactId;
    @SerializedName("before_contact_id")
    @Expose
    private String beforeContactId;

    public String getSearchKeyword() {
        return searchKeyword;
    }

    public void setSearchKeyword(String searchKeyword) {
        this.searchKeyword = searchKeyword;
    }

    public String getAfterContactId() {
        return afterContactId;
    }

    public void setAfterContactId(String afterContactId) {
        this.afterContactId = afterContactId;
    }

    public String getBeforeContactId() {
        return beforeContactId;
    }

    public void setBeforeContactId(String beforeContactId) {
        this.beforeContactId = beforeContactId;
    }

}